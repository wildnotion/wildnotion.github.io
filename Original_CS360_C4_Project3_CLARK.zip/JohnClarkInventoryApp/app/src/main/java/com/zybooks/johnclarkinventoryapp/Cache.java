package com.zybooks.johnclarkinventoryapp;

import java.util.ArrayList;
import java.util.List;

public class Cache {
    private int id;
    private String name;
    private int userId;
    private double latitude;
    private double longitude;
    private byte[] locationImage;
    private List<Item> items;

    public Cache() {
    }

    public Cache(int id, String name, int userId, double latitude, double longitude, byte[] locationImage) {
        this.id = id;
        this.name = name;
        this.userId = userId;
        this.latitude = latitude;
        this.longitude = longitude;
        this.locationImage = locationImage;
        this.items = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public byte[] getLocationImage() {
        return locationImage;
    }

    public void setLocationImage(byte[] locationImage) {
        this.locationImage = locationImage;
    }

    public void addItem(Item item) {
        if (items == null) {
            items = new ArrayList<>();
        }
        items.add(item);
    }

    public List<Item> getItems() {
        return items;
    }
}
