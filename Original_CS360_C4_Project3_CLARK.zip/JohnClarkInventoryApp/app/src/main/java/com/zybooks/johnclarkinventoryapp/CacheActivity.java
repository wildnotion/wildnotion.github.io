package com.zybooks.johnclarkinventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
//import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

//import com.google.android.gms.maps.model.LatLng;
//import com.google.android.gms.location.Geofence;

import java.util.ArrayList;
import java.util.List;

public class CacheActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;
    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 2;
    //private static final float GEOFENCE_RADIUS = 3.048f; // 10 feet in meters

    private DatabaseHelper dbHelper;
    //private GeofenceHelper geofenceHelper;
    private RecyclerView recyclerView;
    private CacheAdapter cacheAdapter;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_cache);

        dbHelper = new DatabaseHelper(this);
        //geofenceHelper = new GeofenceHelper(this);

        userId = getIntent().getIntExtra("USER_ID", -1);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        cacheAdapter = new CacheAdapter(new ArrayList<Cache>());
        recyclerView.setAdapter(cacheAdapter);

        loadCaches();

        Button addCacheButton = findViewById(R.id.btn_add_cache);
        addCacheButton.setOnClickListener(view -> {
            EditText cacheNameField = findViewById(R.id.cache_name);
            String cacheName = cacheNameField.getText().toString();
            double cacheLatitude = 0.0;
            double cacheLongitude = 0.0;

            if (cacheName.isEmpty()) {
                Toast.makeText(this, "Cache name cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            byte[] locationImage = null;
            dbHelper.addCache(cacheName, userId, locationImage, cacheLatitude, cacheLongitude);


            //LatLng cacheLocation = new LatLng(cacheLatitude, cacheLongitude);
            //Geofence geofence = geofenceHelper.createGeofence("CACHE_ID", cacheLocation, GEOFENCE_RADIUS);
            //geofenceHelper.addGeofence(geofence);

            loadCaches();
        });

        Button logoutButton = findViewById(R.id.btn_logout);
        logoutButton.setOnClickListener(view -> {
            Toast.makeText(this, "Logging out", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        checkPermissions();
    }

    private void loadCaches() {

        List<Cache> caches = dbHelper.getCaches(userId);

        cacheAdapter.updateCacheList(caches);
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    MY_PERMISSIONS_REQUEST_SEND_SMS);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                } else {
                }
                break;
            case MY_PERMISSIONS_REQUEST_LOCATION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                } else {
                }
                break;
        }
    }
}
