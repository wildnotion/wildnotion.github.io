package com.zybooks.johnclarkinventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CacheAdapter extends RecyclerView.Adapter<CacheAdapter.ViewHolder> {

    private List<Cache> cacheList;


    public CacheAdapter(List<Cache> cacheList) {
        this.cacheList = cacheList != null ? cacheList : new ArrayList<>();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_cache_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Cache cache = cacheList.get(position);
        holder.cacheNameTextView.setText(cache.getName());
    }

    @Override
    public int getItemCount() {
        return cacheList != null ? cacheList.size() : 0;
    }

    public void updateCacheList(List<Cache> newCacheList) {
        this.cacheList = newCacheList != null ? newCacheList : new ArrayList<>();
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView cacheNameTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cacheNameTextView = itemView.findViewById(R.id.cache_name); // Replace with actual ID
        }
    }
}
