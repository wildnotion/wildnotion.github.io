package com.zybooks.johnclarkinventoryapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class CacheUtils extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "cache.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_CACHES = "caches";
    private static final String KEY_CACHE_ID = "id";
    private static final String KEY_CACHE_NAME = "name";
    private static final String KEY_CACHE_USER_ID = "userId"; // Ensure this matches your database schema
    private static final String KEY_CACHE_LATITUDE = "latitude";
    private static final String KEY_CACHE_LONGITUDE = "longitude";
    private static final String KEY_CACHE_LOCATION_IMAGE = "locationImage";
    private static final String TABLE_ITEMS = "items";
    private static final String KEY_ITEM_CACHE_ID = "cacheId";
    private static final String KEY_ITEM_ID = "id";
    private static final String KEY_ITEM_NAME = "name";
    private static final String KEY_ITEM_COUNT = "count";
    private static final String KEY_ITEM_DESCRIPTION = "description";
    private static final String KEY_ITEM_IMAGE = "image";

    public CacheUtils(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public Cache getCacheWithItems(int cacheId) {
        SQLiteDatabase db = this.getReadableDatabase();

        String queryCache = "SELECT * FROM " + TABLE_CACHES + " WHERE " + KEY_CACHE_ID + " = ?";
        Cursor cursorCache = db.rawQuery(queryCache, new String[]{String.valueOf(cacheId)});

        Cache cache = null;
        if (cursorCache.moveToFirst()) {
            String name = cursorCache.getString(cursorCache.getColumnIndexOrThrow(KEY_CACHE_NAME));
            int userId = cursorCache.getInt(cursorCache.getColumnIndexOrThrow(KEY_CACHE_USER_ID)); // Ensure this column exists in your table
            double latitude = cursorCache.getDouble(cursorCache.getColumnIndexOrThrow(KEY_CACHE_LATITUDE));
            double longitude = cursorCache.getDouble(cursorCache.getColumnIndexOrThrow(KEY_CACHE_LONGITUDE));
            byte[] locationImage = cursorCache.getBlob(cursorCache.getColumnIndexOrThrow(KEY_CACHE_LOCATION_IMAGE));

            cache = new Cache(cacheId, name, userId, latitude, longitude, locationImage);

            String queryItems = "SELECT * FROM " + TABLE_ITEMS + " WHERE " + KEY_ITEM_CACHE_ID + " = ?";
            Cursor cursorItems = db.rawQuery(queryItems, new String[]{String.valueOf(cacheId)});

            if (cursorItems.moveToFirst()) {
                do {
                    int itemId = cursorItems.getInt(cursorItems.getColumnIndexOrThrow(KEY_ITEM_ID));
                    String itemName = cursorItems.getString(cursorItems.getColumnIndexOrThrow(KEY_ITEM_NAME));
                    int itemCount = cursorItems.getInt(cursorItems.getColumnIndexOrThrow(KEY_ITEM_COUNT));
                    String itemDescription = cursorItems.getString(cursorItems.getColumnIndexOrThrow(KEY_ITEM_DESCRIPTION));
                    byte[] itemImage = cursorItems.getBlob(cursorItems.getColumnIndexOrThrow(KEY_ITEM_IMAGE));

                    Item item = new Item(itemId, itemName, itemCount, itemDescription, itemImage, cacheId);
                    cache.addItem(item);
                } while (cursorItems.moveToNext());
            }
            cursorItems.close();
        }
        cursorCache.close();

        return cache;
    }
}
