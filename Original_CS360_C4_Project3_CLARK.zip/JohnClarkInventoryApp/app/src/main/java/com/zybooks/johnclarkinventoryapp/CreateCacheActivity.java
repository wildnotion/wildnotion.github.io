package com.zybooks.johnclarkinventoryapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class CreateCacheActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_PICK_IMAGE = 1;

    private DatabaseHelper dbHelper;
    private int userId;
    private Bitmap locationImage;
    private double latitude;
    private double longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_create_cache);

        dbHelper = new DatabaseHelper(this);

        userId = getIntent().getIntExtra("USER_ID", -1);

        ImageView imageView = findViewById(R.id.cache_image);
        Button selectImageButton = findViewById(R.id.btn_select_image);
        Button addCacheButton = findViewById(R.id.btn_confirm_add);
        Button getCurrentCoordinatesButton = findViewById(R.id.btn_current_coordinates);
        EditText nameField = findViewById(R.id.cache_name);
        EditText latitudeField = findViewById(R.id.cache_latitude);
        EditText longitudeField = findViewById(R.id.cache_longitude);

        selectImageButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, REQUEST_CODE_PICK_IMAGE);
        });

        addCacheButton.setOnClickListener(v -> {
            String cacheName = nameField.getText().toString();
            latitude = Double.parseDouble(latitudeField.getText().toString());
            longitude = Double.parseDouble(longitudeField.getText().toString());

            if (locationImage != null) {
                byte[] locationImageBytes = BitmapUtils.bitmapToByteArray(BitmapUtils.getScaledBitmap(locationImage));
                boolean result = dbHelper.addCache(cacheName, userId, locationImageBytes, latitude, longitude);

                if (result) {
                } else {
                }
            } else {
            }
        });

        getCurrentCoordinatesButton.setOnClickListener(v -> {
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            try {
                locationImage = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                ImageView imageView = findViewById(R.id.cache_image);
                imageView.setImageBitmap(locationImage);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
