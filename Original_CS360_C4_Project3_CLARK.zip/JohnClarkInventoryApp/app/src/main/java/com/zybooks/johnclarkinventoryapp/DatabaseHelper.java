package com.zybooks.johnclarkinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Info
    private static final String DATABASE_NAME = "CacheManager.db";
    private static final int DATABASE_VERSION = 2;

    // Table Names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_CACHES = "caches";
    private static final String TABLE_ITEMS = "items";

    // User Table Columns
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USER_USERNAME = "username";
    private static final String COLUMN_USER_PASSWORD = "password";

    // Cache Table Columns
    private static final String COLUMN_CACHE_ID = "id";
    private static final String COLUMN_CACHE_NAME = "name";
    private static final String COLUMN_CACHE_USER_ID = "user_id";
    private static final String COLUMN_CACHE_LOCATION_IMAGE = "location_image";
    private static final String COLUMN_CACHE_LATITUDE = "latitude";
    private static final String COLUMN_CACHE_LONGITUDE = "longitude";

    // Item Table Columns
    private static final String COLUMN_ITEM_ID = "id";
    private static final String COLUMN_ITEM_NAME = "name";
    private static final String COLUMN_ITEM_COUNT = "count";
    private static final String COLUMN_ITEM_DESCRIPTION = "description";
    private static final String COLUMN_ITEM_IMAGE = "item_image";
    private static final String COLUMN_ITEM_CACHE_ID = "cache_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users Table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS +
                "(" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_USER_USERNAME + " TEXT UNIQUE," +
                COLUMN_USER_PASSWORD + " TEXT" +
                ")";
        db.execSQL(CREATE_USERS_TABLE);

        // Create Caches Table
        String CREATE_CACHES_TABLE = "CREATE TABLE " + TABLE_CACHES +
                "(" +
                COLUMN_CACHE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_CACHE_NAME + " TEXT," +
                COLUMN_CACHE_USER_ID + " INTEGER," +
                COLUMN_CACHE_LATITUDE + " REAL," +
                COLUMN_CACHE_LONGITUDE + " REAL," +
                COLUMN_CACHE_LOCATION_IMAGE + " BLOB," + // Store image as byte array
                "FOREIGN KEY(" + COLUMN_CACHE_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ")" +
                ")";
        db.execSQL(CREATE_CACHES_TABLE);

        // Create Items Table
        String CREATE_ITEMS_TABLE = "CREATE TABLE " + TABLE_ITEMS +
                "(" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_ITEM_NAME + " TEXT," +
                COLUMN_ITEM_COUNT + " INTEGER," +
                COLUMN_ITEM_DESCRIPTION + " TEXT," +
                COLUMN_ITEM_IMAGE + " BLOB," + // Store image as byte array
                COLUMN_ITEM_CACHE_ID + " INTEGER," +
                "FOREIGN KEY(" + COLUMN_ITEM_CACHE_ID + ") REFERENCES " + TABLE_CACHES + "(" + COLUMN_CACHE_ID + ")" +
                ")";
        db.execSQL(CREATE_ITEMS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < newVersion) {
            if (oldVersion < 3) {
                db.execSQL("ALTER TABLE " + TABLE_CACHES + " ADD COLUMN " + COLUMN_CACHE_LOCATION_IMAGE + " BLOB");
            }
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_CACHES);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
            onCreate(db);
        }
    }

    // Method to add a user
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        if (doesUserExist(username)) {
            db.close();
            return false; // User already exists
        }
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_USERNAME, username);
        values.put(COLUMN_USER_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    // Method to authenticate the user
    public boolean authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_USERNAME},
                COLUMN_USER_USERNAME + "=? AND " + COLUMN_USER_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);
        boolean isAuthenticated = cursor.getCount() > 0;
        cursor.close();
        return isAuthenticated;
    }

    // Method to check if a user exists
    public boolean doesUserExist(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_USER_USERNAME},
                COLUMN_USER_USERNAME + "=?",
                new String[]{username}, null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public boolean addCache(String cacheName, int userId, byte[] locationImage, double latitude, double longitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CACHE_NAME, cacheName);
        values.put(COLUMN_CACHE_USER_ID, userId);
        values.put(COLUMN_CACHE_LOCATION_IMAGE, locationImage); // Optional field
        values.put(COLUMN_CACHE_LATITUDE, latitude);
        values.put(COLUMN_CACHE_LONGITUDE, longitude);
        long result = db.insert(TABLE_CACHES, null, values);
        db.close();
        return result != -1;
    }

    public boolean updateCache(int cacheId, String newName, byte[] newLocationImage, double newLatitude, double newLongitude) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CACHE_NAME, newName);
        values.put(COLUMN_CACHE_LOCATION_IMAGE, newLocationImage);
        values.put(COLUMN_CACHE_LATITUDE, newLatitude);
        values.put(COLUMN_CACHE_LONGITUDE, newLongitude);
        int result = db.update(TABLE_CACHES, values, COLUMN_CACHE_ID + "=?", new String[]{String.valueOf(cacheId)});
        db.close();
        return result > 0;
    }

    public boolean addItem(String itemName, int itemCount, String itemDescription, byte[] itemImage, int cacheId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_ITEM_COUNT, itemCount);
        values.put(COLUMN_ITEM_DESCRIPTION, itemDescription);
        values.put(COLUMN_ITEM_IMAGE, itemImage);
        values.put(COLUMN_ITEM_CACHE_ID, cacheId);
        long result = db.insert(TABLE_ITEMS, null, values);
        db.close();
        return result != -1;
    }

    public boolean updateItem(int itemId, String newName, int newCount, String newDescription, byte[] newImage) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, newName);
        values.put(COLUMN_ITEM_COUNT, newCount);
        values.put(COLUMN_ITEM_DESCRIPTION, newDescription);
        values.put(COLUMN_ITEM_IMAGE, newImage);
        int result = db.update(TABLE_ITEMS, values, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        db.close();
        return result > 0;
    }

    public List<Cache> getCaches(int userId) {
        List<Cache> cacheList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_CACHES + " WHERE " + COLUMN_CACHE_USER_ID + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(COLUMN_CACHE_ID));
                String name = cursor.getString(cursor.getColumnIndex(COLUMN_CACHE_NAME));
                double latitude = cursor.getDouble(cursor.getColumnIndex(COLUMN_CACHE_LATITUDE));
                double longitude = cursor.getDouble(cursor.getColumnIndex(COLUMN_CACHE_LONGITUDE));
                byte[] locationImage = cursor.getBlob(cursor.getColumnIndex(COLUMN_CACHE_LOCATION_IMAGE));
                Cache cache = new Cache(id, name, userId, latitude, longitude, locationImage);
                cacheList.add(cache);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return cacheList;
    }

    public List<Item> getItemsForCache(int cacheId) {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_ITEMS, null, COLUMN_ITEM_CACHE_ID + "=?", new String[]{String.valueOf(cacheId)}, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item(
                        cursor.getInt(cursor.getColumnIndex(COLUMN_ITEM_ID)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_ITEM_NAME)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN_ITEM_COUNT)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_ITEM_DESCRIPTION)),
                        cursor.getBlob(cursor.getColumnIndex(COLUMN_ITEM_IMAGE)),
                        cursor.getInt(cursor.getColumnIndex(COLUMN_ITEM_CACHE_ID))
                );
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return itemList;
    }

    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT " + COLUMN_USER_ID + " FROM " + TABLE_USERS + " WHERE " + COLUMN_USER_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        if (cursor != null && cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
            cursor.close();
            return userId;
        }
        cursor.close();
        return -1; // Return -1 if the user ID is not found
    }
}
