package com.zybooks.johnclarkinventoryapp;

import android.content.Intent;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Base64;
import java.util.List;

public class EmailUtils {

    private static String convertToBase64(byte[] image) {
        if (image == null) return "";
        return Base64.encodeToString(image, Base64.DEFAULT);
    }

    public static String formatEmailContent(Cache cache) {
        StringBuilder emailContent = new StringBuilder();

        if (cache.getLocationImage() != null) {
            String imageBase64 = convertToBase64(cache.getLocationImage());
            emailContent.append("Cache Image:\n")
                    .append("data:image/jpeg;base64,").append(imageBase64).append("\n\n");
        }

        emailContent.append("Cache Name: ").append(cache.getName()).append("\n");
        emailContent.append("Cache Location: Latitude: ").append(cache.getLatitude())
                .append(", Longitude: ").append(cache.getLongitude()).append("\n");

        List<Item> items = cache.getItems();
        if (items != null && !items.isEmpty()) {
            emailContent.append("\nItems:\n");
            for (Item item : items) {
                if (item.getImage() != null) {
                    String itemImageBase64 = convertToBase64(item.getImage());
                    emailContent.append("Item Image:\n")
                            .append("data:image/jpeg;base64,").append(itemImageBase64).append("\n");
                }

                emailContent.append("Item Name: ").append(item.getName()).append("\n");
                emailContent.append("Item Description: ").append(item.getDescription()).append("\n");
                emailContent.append("Item Count: ").append(item.getCount()).append("\n\n");
            }
        } else {
            emailContent.append("\nNo items available for this cache.\n");
        }

        return emailContent.toString();
    }

    public void sendEmail(Cache cache, String recipientEmail, AppCompatActivity activity) {
        String subject = "Cache Details";
        String body = formatEmailContent(cache);

        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse("mailto:")); // Only email apps should handle this
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{recipientEmail});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, body);

        if (emailIntent.resolveActivity(activity.getPackageManager()) != null) {
            activity.startActivity(emailIntent);
        } else {
        }
    }
}
