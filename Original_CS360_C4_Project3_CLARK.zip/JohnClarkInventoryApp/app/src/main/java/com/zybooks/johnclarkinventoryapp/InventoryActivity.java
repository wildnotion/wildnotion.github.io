package com.zybooks.johnclarkinventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class InventoryActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private ImageView cacheImageView;
    private TextView cacheNameTextView;
    private TextView cacheLatitudeTextView;
    private TextView cacheLongitudeTextView;
    private EditText cacheIdEditText;
    private Button btnCurrentCoordinates;
    private Button btnAddItem;
    private Button btnShareStash;
    private RecyclerView recyclerView;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_inventory);

        databaseHelper = new DatabaseHelper(this);
        cacheImageView = findViewById(R.id.cache_image);
        cacheNameTextView = findViewById(R.id.cache_name);
        cacheLatitudeTextView = findViewById(R.id.cache_latitude);
        cacheLongitudeTextView = findViewById(R.id.cache_longitude);
        cacheIdEditText = findViewById(R.id.cache_id);
        btnCurrentCoordinates = findViewById(R.id.btn_current_coordinates);
        btnAddItem = findViewById(R.id.btn_add_item);
        btnShareStash = findViewById(R.id.btn_share_stash);
        recyclerView = findViewById(R.id.recycler_view);
        progressBar = findViewById(R.id.progress_bar);
    }
}
