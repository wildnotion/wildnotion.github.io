package com.zybooks.johnclarkinventoryapp;

public class Item {
    private int id;
    private String name;
    private int count;
    private String description;
    private byte[] image;
    private int cacheId;

    public Item(int id, String name, int count, String description, byte[] image, int cacheId) {
        this.id = id;
        this.name = name;
        this.count = count;
        this.description = description;
        this.image = image;
        this.cacheId = cacheId;
    }

    public Item() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public int getCacheId() {
        return cacheId;
    }

    public void setCacheId(int cacheId) {
        this.cacheId = cacheId;
    }
}
