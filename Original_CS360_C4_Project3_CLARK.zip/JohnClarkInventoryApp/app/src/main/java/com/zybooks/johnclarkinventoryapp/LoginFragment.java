package com.zybooks.johnclarkinventoryapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {

    private EditText usernameField;
    private EditText passwordField;
    private Button loginButton;
    private Button createAccountButton;
    private DatabaseHelper dbHelper;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dbHelper = new DatabaseHelper(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_login, container, false);

        usernameField = view.findViewById(R.id.username);
        passwordField = view.findViewById(R.id.password);
        loginButton = view.findViewById(R.id.btn_login);
        createAccountButton = view.findViewById(R.id.btn_create_account);

        loginButton.setOnClickListener(v -> loginUser());
        createAccountButton.setOnClickListener(v -> createUser());

        return view;
    }

    private void loginUser() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (dbHelper.authenticateUser(username, password)) {
            // Navigate to DashboardFragment
            ((MainActivity) getActivity()).showDashboardFragment();
        } else {
            Toast.makeText(getActivity(), "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private void createUser() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(getActivity(), "Username and password cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.doesUserExist(username)) {
            Toast.makeText(getActivity(), "Username already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isAdded = dbHelper.addUser(username, password);
        if (isAdded) {
            // Navigate to DashboardFragment
            ((MainActivity) getActivity()).showDashboardFragment();
        } else {
            Toast.makeText(getActivity(), "Account creation failed", Toast.LENGTH_SHORT).show();
        }
    }
}

