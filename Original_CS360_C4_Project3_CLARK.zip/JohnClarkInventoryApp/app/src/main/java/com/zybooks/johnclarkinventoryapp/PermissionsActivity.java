package com.zybooks.johnclarkinventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

public class PermissionsActivity extends Fragment {

    private TextView gpsStatusText, galleryStatusText, cameraStatusText, smsStatusText;

    // Permission launcher
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> updatePermissionsStatus());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.layout_permissions, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        gpsStatusText = view.findViewById(R.id.gps_status);
        galleryStatusText = view.findViewById(R.id.gallery_status);
        cameraStatusText = view.findViewById(R.id.camera_status);
        smsStatusText = view.findViewById(R.id.sms_status);

        // Set up buttons
        view.findViewById(R.id.btn_gps_permission).setOnClickListener(v -> requestPermission(Manifest.permission.ACCESS_FINE_LOCATION));
        view.findViewById(R.id.btn_gallery_permission).setOnClickListener(v -> requestGalleryPermission());
        view.findViewById(R.id.btn_camera_permission).setOnClickListener(v -> requestPermission(Manifest.permission.CAMERA));
        view.findViewById(R.id.btn_sms_permission).setOnClickListener(v -> requestPermission(Manifest.permission.RECEIVE_SMS));
        view.findViewById(R.id.btn_confirm_permissions).setOnClickListener(v -> proceedToCacheFragment());
        view.findViewById(R.id.btn_app_settings).setOnClickListener(v -> openAppSettings());

        updatePermissionsStatus();
    }

    private void updatePermissionsStatus() {
        updateStatusText(gpsStatusText, Manifest.permission.ACCESS_FINE_LOCATION);
        updateStatusText(galleryStatusText, checkGalleryPermission());
        updateStatusText(cameraStatusText, Manifest.permission.CAMERA);
        updateStatusText(smsStatusText, Manifest.permission.RECEIVE_SMS);
    }

    private void updateStatusText(TextView statusTextView, boolean isGranted) {
        statusTextView.setText(isGranted ? "Permission granted" : "Permission denied");
        statusTextView.setTextColor(ContextCompat.getColor(requireContext(), isGranted ? android.R.color.holo_green_dark : android.R.color.holo_red_dark));
    }

    private void updateStatusText(TextView statusTextView, String permission) {
        updateStatusText(statusTextView, ContextCompat.checkSelfPermission(requireContext(), permission) == PackageManager.PERMISSION_GRANTED);
    }

    private void requestPermission(String permission) {
        if (ContextCompat.checkSelfPermission(requireContext(), permission) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(permission);
        } else {
            updatePermissionsStatus();
        }
    }

    private void requestGalleryPermission() {
        String permission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        requestPermission(permission);
    }

    private boolean checkGalleryPermission() {
        String permission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        return ContextCompat.checkSelfPermission(requireContext(), permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void proceedToCacheFragment() {
        SharedPreferences prefs = requireActivity().getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(MainActivity.KEY_PERMISSIONS_SET, true).apply();

        requireActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new DashboardFragment())
                .commit();
    }

    private void openAppSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(android.net.Uri.parse("package:" + requireActivity().getPackageName()));
        startActivity(intent);
    }
}
