package com.zybooks.johnclarkinventoryapp;

import static com.zybooks.johnclarkinventoryapp.EmailUtils.formatEmailContent;

import android.content.Intent;
import android.net.Uri;

import java.util.ArrayList;
/*
public void sendEmail(Cache cache) {
    Intent emailIntent = new Intent(Intent.ACTION_SEND_MULTIPLE);
    emailIntent.setType("message/rfc822");
    emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Cache Details: " + cache.getName());

    String emailContent = formatEmailContent(cache);
    emailIntent.putExtra(Intent.EXTRA_TEXT, emailContent);

    ArrayList<Uri> uris = new ArrayList<>();

    if (cache.getLocationImage() != null) {
        Uri cacheImageUri = saveImageToExternalStorage(cache.getLocationImage(), "cache_image.png");
        if (cacheImageUri != null) {
            uris.add(cacheImageUri);
        }
    }

    for (Item item : cache.getItems()) {
        if (item.getImage() != null) {
            Uri itemImageUri = saveImageToExternalStorage(item.getImage(), item.getName() + "_image.png");
            if (itemImageUri != null) {
                uris.add(itemImageUri);
            }
        }
    }

    if (!uris.isEmpty()) {
        emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
    }

    try {
        startActivity(Intent.createChooser(emailIntent, "Send email using..."));
    } catch (android.content.ActivityNotFoundException ex) {
        Toast.makeText(this, "No email clients installed.", Toast.LENGTH_SHORT).show();
    }
}

private Uri saveImageToExternalStorage(byte[] imageBytes, String fileName) {
    try {
        File file = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), fileName);
        FileOutputStream fos = new FileOutputStream(file);
        fos.write(imageBytes);
        fos.close();
        return FileProvider.getUriForFile(this, getPackageName() + ".provider", file);
    } catch (IOException e) {
        e.printStackTrace();
        return null;
    }
}*/

