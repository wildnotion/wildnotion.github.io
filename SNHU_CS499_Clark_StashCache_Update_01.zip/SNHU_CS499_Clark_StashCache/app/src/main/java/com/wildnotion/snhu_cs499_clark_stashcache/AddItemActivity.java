package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddItemActivity extends AppCompatActivity {
    SessionManager sessionManager = SessionManager.getSession(); // For keeping track of logged in user

    Button testSwitch; // To test activity switching
    Button backButton;
    Button testSwitch2;
    Button testSwitch3;
    Button testSwitch4;
    Button testSwitch5;
    Button testSwitch6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        testSwitch = (Button) findViewById(R.id.testSwitch); // Button to test activity switching
        backButton = (Button) findViewById(R.id.logoutButton);
        testSwitch2 = (Button) findViewById(R.id.testSwitch2);
        testSwitch3 = (Button) findViewById(R.id.testSwitch3);
        testSwitch4 = (Button) findViewById(R.id.createCacheButton);
        testSwitch5 = (Button) findViewById(R.id.testSwitch5);
        testSwitch6 = (Button) findViewById(R.id.testSwitch6);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        int sessionID = sessionManager.getUserId();
        Toast.makeText(this, "Current Session: " + sessionID, Toast.LENGTH_SHORT).show();

        testSwitch.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                MainActivity();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        testSwitch2.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                PermissionsActivity();
            }
        });

        testSwitch3.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                LoginActivity();
            }
        });

        testSwitch4.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                CreateCacheActivity();
            }
        });

        testSwitch5.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                InventoryActivity();
            }
        });

        testSwitch6.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                CacheActivity();
            }
        });
    }

    public void MainActivity(){
        Intent intent = new Intent (this, MainActivity.class);
        startActivity(intent);
    }

    public void PermissionsActivity(){
        Intent intent = new Intent (this, PermissionsActivity.class);
        startActivity(intent);
    }

    public void LoginActivity(){
        Intent intent = new Intent (this, LoginActivity.class);
        startActivity(intent);
    }

    public void CreateCacheActivity(){
        Intent intent = new Intent (this, CreateCacheActivity.class);
        startActivity(intent);
    }

    public void InventoryActivity(){
        Intent intent = new Intent (this, InventoryActivity.class);
        startActivity(intent);
    }

    public void CacheActivity(){
        Intent intent = new Intent (this, CacheActivity.class);
        startActivity(intent);
    }
}