package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CacheActivity extends AppCompatActivity {
    // For keeping track of logged in user
    private SessionManager sessionManager;
    DatabaseManager databaseManager = new DatabaseManager(this);

    // Testing SQLViewAdapter
    private RecyclerView recyclerView;
    private SQLCacheViewAdapter sqlCacheViewAdapter;
    private List<CacheModel> cacheModelList;

    Button createCacheButton; // To test activity switching
    Button logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cache);

        sessionManager = SessionManager.getSession();

        createCacheButton = findViewById(R.id.createCacheButton);
        logoutButton = findViewById(R.id.logoutButton);

        int sessionID = sessionManager.getUserId();
        Toast.makeText(this, "Current Session: " + sessionID, Toast.LENGTH_SHORT).show();


        // Testing SQLViewAdapter
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
            // For lines in the recycler view
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        cacheModelList = databaseManager.getUserCaches();
        sqlCacheViewAdapter = new SQLCacheViewAdapter(cacheModelList,
            new SQLCacheViewAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int position) {
                    CacheModel cacheClicked = cacheModelList.get(position);
                    Toast.makeText(CacheActivity.this, "Clicked cache: " + cacheClicked.getName(), Toast.LENGTH_SHORT).show();
                    int inventoryChoice = cacheClicked.getId();
                }
            },
            databaseManager
        );
        recyclerView.setAdapter(sqlCacheViewAdapter);
        //

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        createCacheButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                CreateCacheActivity();
                finish();
            }
        });

        logoutButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                sessionManager.setUserId(-1);
                LoginActivity();
                finish();
            }
        });

    }

    public void LoginActivity(){
        Intent intent = new Intent (this, LoginActivity.class);
        startActivity(intent);
    }

    public void CreateCacheActivity(){
        Intent intent = new Intent (this, CreateCacheActivity.class);
        startActivity(intent);
    }
}