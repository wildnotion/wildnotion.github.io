package com.wildnotion.snhu_cs499_clark_stashcache;

public class CacheModel {
    private int id;
    private int userId;
    private String name;
    private String hint;
    private float latitude;
    private float longitude;
    private int image;

    public CacheModel(int id, int userId, String name, String hint, float latitude, float longitude, int image){
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.hint = hint;
        this.latitude = latitude;
        this.longitude = longitude;
        this.image = image;
    }

    // Constructor for listing
    public CacheModel(int id, String name, String hint) {
        this.id = id;
        this.name = name;
        this.hint = hint;
    }

    // Constructor for listing
    public CacheModel(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    public float getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public float getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
