package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateCacheActivity extends AppCompatActivity {
    // For keeping track of logged in user
    private SessionManager sessionManager;
    public DatabaseManager databaseManager;

    Button backButton;
    Button createButton;
    EditText etName;
    EditText etHint;
    EditText etLatitude;
    EditText etLongitude;
    ImageView ivCache;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_cache);

        databaseManager = DatabaseManager.getInstance(this);
        sessionManager = SessionManager.getSession();

        backButton = findViewById(R.id.backButton);
        createButton = findViewById(R.id.createButton);
        etName = findViewById(R.id.etName);
        etHint = findViewById(R.id.etHint);
        etLatitude = findViewById(R.id.etLatitude);
        etLongitude = findViewById(R.id.etLongitude);
        ivCache = findViewById(R.id.ivCache);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        int sessionID = sessionManager.getUserId();
        Toast.makeText(this, "Current Session: " + sessionID, Toast.LENGTH_SHORT).show();


        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Only allow the create button to be clicked when a name is entered
                if (charSequence.toString().trim().isEmpty()){
                    createButton.setEnabled(false);
                } else {
                    createButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        backButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                CacheActivity();
                finish();
            }
        });

        createButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                int id = 0;
                int userId = sessionManager.getUserId();
                String name = etName.getText().toString();
                String hint = etHint.getText().toString();
                String latitudeString = etLatitude.getText().toString();
                String longitudeString = etLongitude.getText().toString();
                //String image = ivCache.getText().toString();
                float latitude;
                float longitude = 0.0F;

                try {
                    latitude = Float.parseFloat(latitudeString);
                } catch (NumberFormatException exception) {
                    latitude = 0.0F;
                    Toast.makeText(CreateCacheActivity.this, "Improper float for latitude.", Toast.LENGTH_SHORT).show();
                }

                try {
                    longitude = Float.parseFloat(longitudeString);
                } catch (NumberFormatException exception) {
                    longitude = 0.0F;
                    Toast.makeText(CreateCacheActivity.this, "Improper float for longitude.", Toast.LENGTH_SHORT).show();
                }

                boolean isNewCacheCreated = databaseManager.createNewCache(new CacheModel(id ,userId, name, hint, latitude, longitude, 0 ));

                if (isNewCacheCreated) {
                    Toast.makeText(CreateCacheActivity.this, "Created a cache.", Toast.LENGTH_SHORT).show();
                    CacheActivity();
                    finish();
                } else {
                    Toast.makeText(CreateCacheActivity.this, "Failed to create a cache.", Toast.LENGTH_SHORT).show();
                    CacheActivity();
                    finish();
                }
            }
        });

        /* Adding a cache
        boolean test4 = databaseManager.createNewCache(new CacheModel(currentSession, "Bugs", "", 1.0F, 1.0F, 1));
         */
    }

    public void CacheActivity(){
        Intent intent = new Intent (this, CacheActivity.class);
        startActivity(intent);
    }
}