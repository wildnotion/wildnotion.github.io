package com.wildnotion.snhu_cs499_clark_stashcache;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DatabaseManager extends SQLiteOpenHelper {
    // For keeping track of the logged in user
    SessionManager sessionManager = SessionManager.getSession();

    // Database name, version, and instance declarations
    private static final String DATABASE_NAME = "StashCache.db";
    private static final int DATABASE_VERSION = 1;
    private static DatabaseManager instance;

    // Username and password table
    private static final String USER_TABLE = "USER_TABLE";
    private static final String COLUMN_USER_ID = "ID";
    private static final String COLUMN_USER_NAME = "USERNAME";
    private static final String COLUMN_USER_PASS = "PASSWORD";

    // Individual cache table
    private static final String CACHE_TABLE = "CACHE_TABLE";
    private static final String COLUMN_CACHE_ID = "ID";
    private static final String COLUMN_CACHE_USER_ID = "USER_ID";
    private static final String COLUMN_CACHE_NAME = "NAME";
    private static final String COLUMN_CACHE_HINT = "HINT";
    private static final String COLUMN_CACHE_LATITUDE = "LATITUDE";
    private static final String COLUMN_CACHE_LONGITUDE = "LONGITUDE";
    private static final String COLUMN_CACHE_IMAGE = "IMAGE";

    // Individual item table
    private static final String ITEM_TABLE = "ITEM_TABLE";
    private static final String COLUMN_ITEM_ID = "ID";
    private static final String COLUMN_ITEM_CACHE_ID = "CACHE_ID";
    private static final String COLUMN_ITEM_NAME = "NAME";
    private static final String COLUMN_ITEM_DESCRIPTION = "DESCRIPTION";
    private static final String COLUMN_ITEM_COUNT = "COUNT";
    private static final String COLUMN_ITEM_IMAGE = "IMAGE";

    // Booting from main for initialization
    // FIXME Add comments for better understanding
    public static synchronized DatabaseManager getInstance(Context context){
        if (instance == null){
            instance = new DatabaseManager(context.getApplicationContext());
        }
        return instance;
    }

    // Necessary Constructor for creating databases in SQLite
    public DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Necessary override of the extended SQLiteOpenHelper
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Create a master username password table
        String createMasterUserPassTable = "CREATE TABLE " + USER_TABLE + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_NAME + " TEXT NOT NULL UNIQUE, "
                + COLUMN_USER_PASS + " TEXT NOT NULL);";
        sqLiteDatabase.execSQL(createMasterUserPassTable);

        // Create a master cache table
        String createMasterCacheTable = "CREATE TABLE " + CACHE_TABLE + " (" +
                COLUMN_CACHE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_CACHE_USER_ID + " INTEGER NOT NULL, " +
                COLUMN_CACHE_NAME + " TEXT NOT NULL, " +
                COLUMN_CACHE_HINT + " TEXT, " +
                COLUMN_CACHE_LATITUDE + " REAL, " +
                COLUMN_CACHE_LONGITUDE + " REAL, " +
                COLUMN_CACHE_IMAGE + " INTEGER, " +
                "FOREIGN KEY(" + COLUMN_CACHE_USER_ID + ") REFERENCES " +
                USER_TABLE + "(" + COLUMN_USER_ID + "));";
        sqLiteDatabase.execSQL(createMasterCacheTable);

        // Create a master item table
        String createMasterItemTable = "CREATE TABLE " + ITEM_TABLE + " (" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_CACHE_ID + " INTEGER NOT NULL, " +
                COLUMN_ITEM_NAME + " TEXT NOT NULL, " +
                COLUMN_ITEM_DESCRIPTION + " TEXT, " +
                COLUMN_ITEM_COUNT + " INTEGER, " +
                COLUMN_ITEM_IMAGE + " INTEGER, " +
                "FOREIGN KEY(" + COLUMN_ITEM_CACHE_ID + ") REFERENCES " +
                CACHE_TABLE + "(" + COLUMN_CACHE_ID + "));";
        sqLiteDatabase.execSQL(createMasterItemTable);

    }

    // Necessary override of the extended SQLiteOpenHelper
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        // FIXME Replace current destroy-everything with alter-everything for tables
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + CACHE_TABLE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + ITEM_TABLE);
        this.onCreate(sqLiteDatabase);
    }

    public boolean createNewUser(UserPassModel userPassModel){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //contentValues.put(COLUMN_USER_ID, userPassModel.getId());
        contentValues.put(COLUMN_USER_NAME, userPassModel.getUsername());
        contentValues.put(COLUMN_USER_PASS, userPassModel.getPassword());

        long result = sqLiteDatabase.insert(USER_TABLE, null, contentValues);

        // FIXME: Add better error handling
        return result != -1;
    }


    public boolean createNewCache(CacheModel cacheModel){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_CACHE_USER_ID, cacheModel.getUserId());
        contentValues.put(COLUMN_CACHE_NAME, cacheModel.getName());
        contentValues.put(COLUMN_CACHE_HINT, cacheModel.getHint());
        contentValues.put(COLUMN_CACHE_LATITUDE, cacheModel.getLatitude());
        contentValues.put(COLUMN_CACHE_LONGITUDE, cacheModel.getLongitude());
        contentValues.put(COLUMN_CACHE_IMAGE, cacheModel.getImage());

        long result = sqLiteDatabase.insert(CACHE_TABLE, null, contentValues);

        if (result != -1){
            cacheModel.setId((int) result);
            Log.d("DatabaseManager", String.valueOf(cacheModel.getId()));
            return true;
        } else {
            return false;
        }
    }

    public boolean addItemToCache(ItemModel itemModel){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_ITEM_CACHE_ID, itemModel.getCacheId());
        contentValues.put(COLUMN_ITEM_NAME, itemModel.getName());
        contentValues.put(COLUMN_ITEM_DESCRIPTION, itemModel.getDescription());
        contentValues.put(COLUMN_ITEM_COUNT, itemModel.getCount());
        contentValues.put(COLUMN_ITEM_IMAGE, itemModel.getImage());

        long result = sqLiteDatabase.insert(ITEM_TABLE, null, contentValues);

        // FIXME: Add better error handling
        return result != -1;
    }

    public List<CacheModel> getUserCaches(){
        List<CacheModel> userCaches = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        int sessionID = sessionManager.getUserId();

        String sqlQuery = "SELECT * FROM " + CACHE_TABLE + " WHERE " + COLUMN_CACHE_USER_ID + " = ?";
        Cursor cursor = sqLiteDatabase.rawQuery(sqlQuery, new String[]{String.valueOf(sessionID)});

        try {
            if (cursor.moveToFirst()) {
                do {
                    // FIXME Add better null checks
                    int cacheID = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_ID));
                    String cacheName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_NAME));
                    String cacheHint = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_HINT));
                    userCaches.add(new CacheModel(cacheID, cacheName, cacheHint));
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            //sqLiteDatabase.close();
        }

        return userCaches;
    }

    public List<ItemModel> getCurrentCacheItems(int cacheID){
        List<ItemModel> cacheItems = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        String sqlQuery = "SELECT * FROM " + ITEM_TABLE + " WHERE " + COLUMN_ITEM_CACHE_ID + " = ?";
        Cursor cursor = sqLiteDatabase.rawQuery(sqlQuery, new String[]{String.valueOf(cacheID)});

        try {
            if (cursor.moveToFirst()) {
                do {
                    String itemName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                    String itemDescription = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_DESCRIPTION));
                    int itemCount = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_COUNT));
                    int itemImage = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_IMAGE));
                    cacheItems.add(new ItemModel(itemName, itemDescription, itemCount, itemImage));
                } while (cursor.moveToNext());
            }
        } finally {
            cursor.close();
            //sqLiteDatabase.close();
        }

        return cacheItems;
    }

    public UserPassModel getUsernameID(String username){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.query(USER_TABLE, new String[] { COLUMN_USER_ID, COLUMN_USER_NAME,
                        COLUMN_USER_PASS }, COLUMN_USER_NAME + "=?", new String[] { username },
                null, null, null);

        if (cursor.moveToFirst()) {
            @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
            @SuppressLint("Range") String password = cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASS));
            cursor.close();
            UserPassModel userPassModel = new UserPassModel(username, password);
            userPassModel.setId(id);
            return userPassModel;
        }

        return null;
    }

    public boolean deleteCacheById(int cacheID) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        int userID = sessionManager.getUserId();
        Log.d("DatabaseManager", "Trying to delete cacheID: " + cacheID + " from userID" + userID);

        int success = sqLiteDatabase.delete(CACHE_TABLE, COLUMN_CACHE_ID + " = ? AND " +
                COLUMN_CACHE_USER_ID + " = ?", new String[]{String.valueOf(cacheID), String.valueOf(userID)});

        if (success > 0) {
            Log.d("DatabaseManager", "Deleted!");
        } else {
            Log.d("DatabaseManager", "Not deleted...");
        }

        return success > 0;
    }
                /*
        String theWhere = COLUMN_CACHE_ID + " = ? AND " + COLUMN_CACHE_USER_ID + " = ?";
        String[] argsWhere = {String.valueOf(cacheID), String.valueOf(userID)};

        int deletedRows = sqLiteDatabase.delete(CACHE_TABLE, theWhere, argsWhere);
        if (deletedRows > 0) {
            Log.d("Database Manager", String.format("%d Deleted from %d", cacheID, userID));
        } else {
            Log.d("Database Manager", "Nothing deleted");
        }
        sqLiteDatabase.delete(CACHE_TABLE, theWhere, argsWhere);
        sqLiteDatabase.close();


        /*
        sqLiteDatabase.execSQL("DELETE FROM " + CACHE_TABLE + " WHERE " + COLUMN_CACHE_ID +
                " = " + cacheID + " AND " + COLUMN_CACHE_USER_ID + " = " + userID);
        */
}
