package com.wildnotion.snhu_cs499_clark_stashcache;

public class ItemModel {
    private int id;
    private int cacheId;
    private String name;
    private String description;
    private int count;
    private int image;

    public ItemModel(int cacheId, String name, String description, int count, int image){
        this.cacheId = cacheId;
        this.name = name;
        this.description = description;
        this.count = count;
        this.image = image;
    }

    // Constructor for listing
    public ItemModel(String name, String description, int count, int image) {
        this.name = name;
        this.description = description;
        this.count = count;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getCacheId() {
        return cacheId;
    }

    public void setCacheId(int cacheId) {
        this.cacheId = cacheId;
    }
}
