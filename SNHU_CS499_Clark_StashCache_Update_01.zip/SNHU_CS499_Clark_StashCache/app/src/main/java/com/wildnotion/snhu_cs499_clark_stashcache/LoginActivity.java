package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {
    // For keeping track of logged in user
    private SessionManager sessionManager;
    public DatabaseManager databaseManager;

    EditText usernameField;
    EditText passwordField;
    CheckBox saveCredentials;
    Button loginButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        databaseManager = DatabaseManager.getInstance(this);
        sessionManager = SessionManager.getSession();



        usernameField = findViewById(R.id.etUsername);
        passwordField = findViewById(R.id.etPassword);
        saveCredentials = findViewById(R.id.saveCreds);
        loginButton = findViewById(R.id.loginButton);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        int sessionID = sessionManager.getUserId();
        Toast.makeText(this, "Current Session: " + sessionID, Toast.LENGTH_SHORT).show();


        loginButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                String username = usernameField.getText().toString().trim();
                String password = passwordField.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter a username AND password.", Toast.LENGTH_SHORT).show();
                } else {
                    // SQLite search for username and password match
                    UserPassModel userPassModel = databaseManager.getUsernameID(username);


                    if (userPassModel == null) {
                        // If the username does not exist in the database,
                        // create a new userID with it and the password
                        boolean isNewUserCreated = databaseManager.createNewUser(new UserPassModel(username, password));

                        if (isNewUserCreated) {
                            userPassModel = databaseManager.getUsernameID(username);
                            // Set session to associated user ID
                            sessionManager.setUserId(userPassModel.getId());

                            // Open the cache selection screen with associated caches displayed
                            CacheActivity();
                            finish();
                        } else {
                            Toast.makeText(LoginActivity.this, "Unable to create a new user.", Toast.LENGTH_SHORT).show();
                        }
                    } else if (userPassModel.getPassword().equals(password)) {
                        // If the username and password match in the database
                        // Set session to associated user ID
                        sessionManager.setUserId(userPassModel.getId());

                        // Open the cache selection screen with associated caches displayed
                        CacheActivity();
                        finish();
                    } else {
                        Toast.makeText(LoginActivity.this, "Username AND password do not match.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    public void CacheActivity(){
        Intent intent = new Intent (this, CacheActivity.class);
        startActivity(intent);
    }
}