package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.view.View; // For view interaction
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    public DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // For creating and initializing a SQLite database
        databaseManager = DatabaseManager.getInstance(this);
        databaseManager.getWritableDatabase();


        /*
        //Test username password table creation
        //boolean test1 =
        try{
            boolean test1 = databaseManager.createNewUser(new UserPassModel("Clark", "Word"));
            boolean test2 = databaseManager.createNewUser(new UserPassModel("John", "Pass"));
            boolean test3 = databaseManager.createNewUser(new UserPassModel("Third", "Third"));
            Toast.makeText(MainActivity.this, "Success? " + test1 + ", " + test2 + ", " + test3, Toast.LENGTH_SHORT).show();
        } catch (Exception exception) {
            Toast.makeText(MainActivity.this, "Usernames already exist.", Toast.LENGTH_SHORT).show();
        }



        int currentSession = sessionManager.getUserId();

        boolean test4 = databaseManager.createNewCache(new CacheModel(currentSession, "Bugs", "", 1.0F, 1.0F, 1));
        boolean test5 = databaseManager.createNewCache(new CacheModel(currentSession, "Bees", "", 1.0F, 1.0F, 2));
        boolean test6 = databaseManager.createNewCache(new CacheModel(currentSession, "Birds", "", 1.0F, 1.0F, 3));
        Toast.makeText(MainActivity.this, "Success? " + test4 + ", " + test5 + ", " + test6, Toast.LENGTH_SHORT).show();

        // int currentCache = getCacheId(); //FIXME need to connect the cacheIDs to each Item automatically
        boolean test7 = databaseManager.addItemToCache(new ItemModel(1, "Beetle", "Small and green", 7, 1));
        boolean test8 = databaseManager.addItemToCache(new ItemModel(1, "Snail", "Gooey", 3, 7));
        boolean test9 = databaseManager.addItemToCache(new ItemModel(1, "Sparrow", "", 1, 3));
        Toast.makeText(MainActivity.this, "Success? " + test7 + ", " + test8 + ", " + test9, Toast.LENGTH_SHORT).show();
        */

        LoginActivity();

        /*
        boolean test1 = databaseManager.createNewUser(userPassModel);

        //Test cache table creation
        //boolean test2 = databaseManager.createCacheTable(new CacheModel(1, "text1", "text2", 2.0F, 3.0F, 1 ));
        //boolean test2 = databaseManager.createCacheTable(cacheModel, "John");
        */
    }

    public void LoginActivity(){
        Intent intent = new Intent (this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}