package com.wildnotion.snhu_cs499_clark_stashcache;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SQLCacheViewAdapter extends RecyclerView.Adapter<SQLCacheViewAdapter.SQLViewHolder> {
    private final List<CacheModel> cacheModelList;
    private final OnItemClickListener cacheListener; // For clicking on caches
    public DatabaseManager databaseManager;


    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public SQLCacheViewAdapter(List<CacheModel> cacheModelList, OnItemClickListener cacheListener, DatabaseManager databaseManager) {
        this.cacheModelList = cacheModelList;
        this.cacheListener = cacheListener;
        this.databaseManager = databaseManager;
    }

    @NonNull
    @Override
    public SQLViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_cache, parent, false);
        return new SQLViewHolder(view);
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onBindViewHolder(@NonNull SQLViewHolder holder, int position) {
        CacheModel cacheModel = cacheModelList.get(position);
        holder.tvName.setText(cacheModel.getName());

        // FIXME clarifying comments
        holder.ivDeleteImage.setOnClickListener(view -> {
            int cacheID = cacheModel.getId();
            deleteCache(cacheID);
            cacheModelList.remove(position);
            notifyItemRemoved(position);

            // Once the list is empty, ensures Recycler view updates correctly
            if (cacheModelList.isEmpty()){
                notifyDataSetChanged();
            } else {
                notifyItemRangeChanged(position, cacheModelList.size());
            }
        });

        holder.itemView.setOnClickListener(view -> {
            if (cacheListener != null) {
                cacheListener.onItemClick(position);
            }
        });
    }

    private void deleteCache(int cacheID) {
        int userID = SessionManager.getSession().getUserId();

        Log.d("SQLCacheViewAdapter", "Trying to delete cacheID: " + cacheID + " from userID" + userID);

        boolean success = databaseManager.deleteCacheById(cacheID);
        if (success){
            Log.d("SQLCacheViewAdapter", String.format("%d Deleted from %d", cacheID, userID));
        } else {
            Log.d("SQLCacheViewAdapter", "Nothing deleted");
        }
    }

    @Override
    public int getItemCount() {
        //FIXME Add clarifying comments from Android IDE auto help
        return cacheModelList != null ? cacheModelList.size() : 0;
    }

    public static class SQLViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        ImageView ivDeleteImage;

        public SQLViewHolder(@NonNull View cacheView) {
            super(cacheView);
            tvName = cacheView.findViewById(R.id.tvName);
            ivDeleteImage = cacheView.findViewById(R.id.ivDeleteImage);
        }
    }
}
