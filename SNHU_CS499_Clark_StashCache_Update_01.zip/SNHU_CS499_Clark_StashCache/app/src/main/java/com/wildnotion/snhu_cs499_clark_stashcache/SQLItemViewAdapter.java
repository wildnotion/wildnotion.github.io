package com.wildnotion.snhu_cs499_clark_stashcache;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SQLItemViewAdapter extends RecyclerView.Adapter<SQLItemViewAdapter.SQLViewHolder> {
    private List<ItemModel> itemModelList;

    public SQLItemViewAdapter(List<ItemModel> itemModelList) {
        this.itemModelList = itemModelList;
    }

    @NonNull
    @Override
    public SQLViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new SQLViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SQLViewHolder holder, int position) {
        ItemModel itemModel = itemModelList.get(position);
        holder.tvName.setText(itemModel.getName());
        holder.tvDescription.setText(itemModel.getDescription());
        holder.tvCount.setText(itemModel.getCount());
        holder.tvImage.setText(itemModel.getImage());
    }

    @Override
    public int getItemCount() {
        //return 0;
        //FIXME huh?
        return itemModelList != null ? itemModelList.size() : 0;
    }

    public static class SQLViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        TextView tvDescription;
        TextView tvCount;
        TextView tvImage; //FIXME change to image reference using the stored integer

        public SQLViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvCount = itemView.findViewById(R.id.tvCount);
            tvImage = itemView.findViewById(R.id.tvImage);
        }
    }
}
