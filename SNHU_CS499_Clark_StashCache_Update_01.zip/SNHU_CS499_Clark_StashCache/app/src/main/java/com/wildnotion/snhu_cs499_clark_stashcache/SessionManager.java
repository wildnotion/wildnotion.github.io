package com.wildnotion.snhu_cs499_clark_stashcache;

// Used when logging in as a reference for the SQLite tables
public class SessionManager {
    private static SessionManager session;
    private int userId;

    // Constructor
    private SessionManager(){
    }

    // Singleton pattern in getter, no need for setter
    public static SessionManager getSession() {
        if(session == null){
            session = new SessionManager();
        }
        return session;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void logoutSession(){
        this.userId = -1;
    }
}
