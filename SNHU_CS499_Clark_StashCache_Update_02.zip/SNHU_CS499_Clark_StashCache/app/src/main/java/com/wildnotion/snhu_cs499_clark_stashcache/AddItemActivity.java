package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddItemActivity extends AppCompatActivity {
    // Singleton class to keep track of logged in user and chosen cache
    SessionManager sessionManager;

    // Methods for dealing with the SQLite database
    DatabaseManager databaseManager;

    private final int[] drawableItemIDs = {
            R.drawable.item_coin, R.drawable.item_candy, R.drawable.item_dairy,
            R.drawable.item_jewelry, R.drawable.item_eggs, R.drawable.item_sock,
            R.drawable.item_scissors, R.drawable.item_lens, R.drawable.item_keys
    };

    private int chosenImageIndex = 0;

    int cacheID;

    Button backButton;
    Button addButton;
    EditText etName;
    EditText etDescription;
    EditText etCount;
    ImageView ivItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        try {
            cacheID = sessionManager.getCacheID();
        } catch (Error e) {
            cacheID = -1;
        }

        backButton = findViewById(R.id.backButton);
        addButton = findViewById(R.id.addButton);
        etName = findViewById(R.id.etName);
        etDescription = findViewById(R.id.etDescription);
        etCount = findViewById(R.id.etCount);

        ivItem = findViewById(R.id.ivItem);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        int sessionID = sessionManager.getUserId();
        //Toast.makeText(this, "Current Session: " + sessionID + "/nCurrent Cache: " + cacheID, Toast.LENGTH_SHORT).show();

        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Only allow the Add Item  button to be clicked when a name is entered
                if (charSequence.toString().trim().isEmpty()){
                    addButton.setEnabled(false);
                } else {
                    addButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        ivItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayImageGrid();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                InventoryActivity();
                finish();
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                int id = 0;
                int cacheId = sessionManager.getCacheID();
                String name = etName.getText().toString();
                String description = etDescription.getText().toString();
                String countString = etCount.getText().toString();
                int count = 0;

                if (!countString.isEmpty()){
                    try{
                        count = Integer.parseInt(countString);
                    }catch(NumberFormatException e){
                        Log.e("Error", "Count not a valid number");
                    }
                }
                Log.d("AddItemActivity", "Chosen image ID: " + chosenImageIndex);

                if (chosenImageIndex < 0 || chosenImageIndex >= drawableItemIDs.length){

                    chosenImageIndex = 0; // If the image ID falls out of bounds, reset it to 0
                }

                boolean isNewItemCreated = databaseManager.addItemToCache(new ItemModel(id , cacheId, name, description, count, chosenImageIndex));

                if (isNewItemCreated) {
                    Toast.makeText(AddItemActivity.this, "Added an item to cache ID: " + cacheID, Toast.LENGTH_SHORT).show();
                    Log.d("AddItemActivity", "Added an item to cache ID: " + cacheID);
                } else {
                    Toast.makeText(AddItemActivity.this, "Failed to add an item.", Toast.LENGTH_SHORT).show();
                    Log.d("AddItemActivity", "Failed to add an item to cache ID: " + cacheID);
                }
                InventoryActivity();
                finish();
            }
        });

        // Managing the back stack and keeping the database updated by manually handling the back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    Log.d("AddItemActivity", "Back button pressed, navigating to Inventory activity.");
                    InventoryActivity();
                    finish();
                } catch (Exception e) {
                    Log.e("AddItemActivity", "Error: " + e.getMessage());
                }
            }
        });
    }


    public void InventoryActivity(){
        Intent intent = new Intent (this, InventoryActivity.class);
        startActivity(intent);
    }

    private void displayImageGrid(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose");

        View image_select_grid = getLayoutInflater().inflate(R.layout.image_select_grid, null);
        GridView gridView = image_select_grid.findViewById(R.id.gridView);

        SelectImageGridAdapter adapter = new SelectImageGridAdapter(this, drawableItemIDs);
        gridView.setAdapter(adapter);

        builder.setView(image_select_grid);

        AlertDialog dialog = builder.create();
        dialog.show();

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            chosenImageIndex = position;
            ivItem.setImageResource(drawableItemIDs[chosenImageIndex]);
            dialog.dismiss();
        });
    }
}