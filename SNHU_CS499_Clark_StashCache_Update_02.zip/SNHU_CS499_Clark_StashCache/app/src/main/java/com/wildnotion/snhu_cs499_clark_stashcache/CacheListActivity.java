package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CacheListActivity extends AppCompatActivity {
    // Singleton class to keep track of logged in user and chosen cache
    SessionManager sessionManager;

    // Methods for dealing with the SQLite database
    DatabaseManager databaseManager;

    // For displaying a list of caches stored in the SQLite Database
    private List<CacheModel> cacheModelList;

    // References for the buttons on the user interface
    Button createCacheButton; // To test activity switching
    Button logoutButton;
    Button userDeleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cache);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        // Button assigning when loading the activity
        createCacheButton = findViewById(R.id.createCacheButton);
        logoutButton = findViewById(R.id.logoutButton);
        userDeleteButton = findViewById(R.id.userDeleteButton);

        // Accessing the session information to keep track of current user
        int sessionID = sessionManager.getUserId();
        //Toast.makeText(this, "Current Session: " + sessionID, Toast.LENGTH_SHORT).show();
        Log.d("CacheListActivity", "Current Session: " + sessionID);

        // Setting up the user interface for listing each cache
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Adding separation lines in the user interface recycler view
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        cacheModelList = databaseManager.getUserCaches();

        // Selecting a Goto inventoryactivity based on inventorychoice
        SQLCacheViewAdapter sqlCacheViewAdapter = new SQLCacheViewAdapter(cacheModelList,
                position -> {
                    CacheModel cacheClicked = cacheModelList.get(position);
                    //Toast.makeText(CacheListActivity.this, "Clicked cache: " + cacheClicked.getName() + " ID: " + cacheClicked.getId(), Toast.LENGTH_SHORT).show();
                    Log.d("CacheListActivity", "Clicked cache: " + cacheClicked.getName() + " ID: " + cacheClicked.getId());
                    //int inventoryChoice = cacheClicked.getId();
                    // Goto inventoryactivity based on inventorychoice
                    try {
                        sessionManager.setCacheID(cacheClicked.getId());
                        InventoryActivity();
                        finish();
                    } catch (Error e) {
                        Log.e("CacheListActivity", "Cache not valid, database corrupt.");
                    }
                    //InventoryActivity();
                },
                databaseManager
        );
        recyclerView.setAdapter(sqlCacheViewAdapter);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        createCacheButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                CreateCacheActivity();
                finish();
            }
        });

        logoutButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                sessionManager.logoutSession();
                LoginActivity();
                finish();
            }
        });

        userDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // FIXME Add confirmation prior to deleting
                databaseManager.deleteActiveUser();
                LoginActivity();
                finish();
            }
        });

        // Managing the back stack and keeping the database updated by manually handling the back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    Log.d("CacheListActivity", "Back button pressed, navigating to Login activity.");
                    sessionManager.logoutSession();
                    LoginActivity();
                    finish();
                } catch (Exception e) {
                    Log.e("CacheListActivity", "Error: " + e.getMessage());
                }
            }
        });

    }

    public void LoginActivity(){
        Intent intent = new Intent (this, LoginActivity.class);
        startActivity(intent);
    }

    public void CreateCacheActivity(){
        Intent intent = new Intent (this, CreateCacheActivity.class);
        startActivity(intent);
    }

    public void InventoryActivity(){
        Intent intent = new Intent (this, InventoryActivity.class);
        startActivity(intent);
    }
}