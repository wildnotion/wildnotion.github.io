package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private TextView tvCacheName;
    private TextView tvCacheHint;
    private TextView tvLatitude;
    private TextView tvLongitude;
    private ImageView ivCacheImage;
    RecyclerView recyclerView;

    private final int[] drawableCacheIDs = {
            R.drawable.location_snowy, R.drawable.location_overlook, R.drawable.location_desert,
            R.drawable.location_tavern, R.drawable.location_glade, R.drawable.location_crystal,
            R.drawable.location_basement, R.drawable.location_mushrooms, R.drawable.location_shipwreck
    };

    // Singleton class to keep track of logged in user and chosen cache
    SessionManager sessionManager;

    // Methods for dealing with the SQLite database
    DatabaseManager databaseManager;

    // For displaying a list of items per cache stored in the SQLite Database
    private List<ItemModel> itemModelList;

    // References for the buttons on the user interface
    Button cacheListButton;
    Button addItemButton;

    int cacheID;

    private String cacheName;
    private String cacheHint;
    private float latitude;
    private float longitude;
    private int cacheImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        tvCacheName = findViewById(R.id.tvCacheName);
        tvCacheHint = findViewById(R.id.tvCacheHint);
        tvLatitude = findViewById(R.id.tvLatitude);
        tvLongitude = findViewById(R.id.tvLongitude);
        ivCacheImage = findViewById(R.id.ivCacheImage);

        recyclerView = findViewById(R.id.recyclerView);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        cacheID = sessionManager.getCacheID();

        //FIXME get the cache model that is being used to add items to
        CacheModel cacheModel = databaseManager.getCacheById(cacheID);

        Toast.makeText(this, "Current cacheID: " + cacheID, Toast.LENGTH_SHORT).show();

        if(cacheModel != null) {

            String cacheName = cacheModel.getName();
            String cacheHint = cacheModel.getHint();
            float latitude = cacheModel.getLatitude();
            float longitude = cacheModel.getLongitude();
            int cacheImage = cacheModel.getImage();


/*
            this.cacheName = cacheName;
            this.cacheHint = cacheHint;
            this.latitude = latitude;
            this.longitude = longitude;
            this.cacheImage = cacheImage;
            */

            tvCacheName.setText(cacheName);
            tvCacheHint.setText(cacheHint);
            tvLatitude.setText(String.valueOf(latitude));
            tvLongitude.setText(String.valueOf(longitude));
            ivCacheImage.setImageResource(drawableCacheIDs[cacheImage]);


            cacheListButton = (Button) findViewById(R.id.cacheListButton);
            addItemButton = (Button) findViewById(R.id.addItemButton);

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });

            // Testing SQLViewAdapter

            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            // For lines in the recycler view
            recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

            itemModelList = databaseManager.getCurrentCacheItems(cacheID);

            SQLItemViewAdapter sqlItemViewAdapter = new SQLItemViewAdapter(itemModelList,
                    position -> {
                        ItemModel itemClicked = itemModelList.get(position);
                        //Toast.makeText(InventoryActivity.this, "Item: " + itemClicked.getName() + " ID: " + itemClicked.getId(), Toast.LENGTH_SHORT).show();
                        Log.d("InventoryActivity", "Item: " + itemClicked.getName() + " ID: " + itemClicked.getId());
                    },
                    databaseManager
            );
            recyclerView.setAdapter(sqlItemViewAdapter);
        } else {
            Toast.makeText(this, "Cache access issue.", Toast.LENGTH_SHORT).show();
        }


        // Listen for button click
        cacheListButton.setOnClickListener(view -> {
            CacheListActivity();
            finish();
        });

        // Listen for button click
        addItemButton.setOnClickListener(view -> {
            AddItemActivity();
            finish();
        });

        // Managing the back stack and keeping the database updated by manually handling the back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    Log.d("InventoryActivity", "Back button pressed, navigating to the Cache List activity.");
                    CacheListActivity();
                    finish();
                } catch (Exception e) {
                    Log.e("InventoryActivity", "Error: " + e.getMessage());
                }
            }

        });
    }

    public void CacheListActivity(){
        Intent intent = new Intent (this, CacheListActivity.class);
        startActivity(intent);
    }

    public void AddItemActivity(){
        Intent intent = new Intent (this, AddItemActivity.class);
        startActivity(intent);
    }
}