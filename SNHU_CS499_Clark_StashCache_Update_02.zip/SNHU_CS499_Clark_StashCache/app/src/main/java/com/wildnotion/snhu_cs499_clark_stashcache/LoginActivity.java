package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowCompat;

import android.content.SharedPreferences; // When saving credentials to be repopulated on loading

public class LoginActivity extends AppCompatActivity {
    // Singleton class to keep track of logged in user and chosen cache
    SessionManager sessionManager;

    // Methods for dealing with the SQLite database
    DatabaseManager databaseManager;

    EditText usernameField;
    EditText passwordField;
    CheckBox saveCredentials;
    Button loginButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        //EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        usernameField = findViewById(R.id.etUsername);
        passwordField = findViewById(R.id.etPassword);
        saveCredentials = findViewById(R.id.saveCreds);
        loginButton = findViewById(R.id.loginButton);

        loadOldCredentials();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        int sessionID = sessionManager.getUserId();
        // Toast.makeText(this, "Current Session: " + sessionID, Toast.LENGTH_SHORT).show();


        loginButton.setOnClickListener(new View.OnClickListener() { // Listen for button click
            @Override
            public void onClick(View view) {
                String username = usernameField.getText().toString().trim();
                String password = passwordField.getText().toString().trim();
                boolean hasCredentials = saveCredentials.isChecked();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter a username AND password.", Toast.LENGTH_SHORT).show();
                } else {
                    // SQLite search for username and password match
                    UserPassModel userPassModel = databaseManager.getUsernameID(username);


                    if (userPassModel == null) {
                        // If the username does not exist in the database,
                        // create a new userID with it and the password
                        boolean isNewUserCreated = databaseManager.createNewUser(new UserPassModel(username, password));

                        if (isNewUserCreated) {
                            Toast.makeText(LoginActivity.this, "New account created, " + username + "!", Toast.LENGTH_SHORT).show();
                            userPassModel = databaseManager.getUsernameID(username);
                            // Set session to associated user ID
                            sessionManager.setUserId(userPassModel.getId());
                        } else {
                            Toast.makeText(LoginActivity.this, "Unable to create a new user.", Toast.LENGTH_SHORT).show();
                        }

                    } else if (userPassModel.getPassword().equals(password)) {
                        Toast.makeText(LoginActivity.this, "Welcome back, " + username + "!", Toast.LENGTH_SHORT).show();
                        // If the username and password match in the database
                        // Set session to associated user ID
                        sessionManager.setUserId(userPassModel.getId());
                    } else {
                        //sessionManager.setUserId(-1);
                        Log.d("LoginActivity", "Current session" + sessionManager.getUserId());
                        Toast.makeText(LoginActivity.this, "Sorry, " + username + ".\nWrong password.", Toast.LENGTH_SHORT).show();
                    }

                    if (userPassModel != null && sessionManager.getUserId() != -1){
                        saveNewCredentials(username, password, hasCredentials);

                        // Open the cache selection screen with associated caches displayed
                        CacheActivity();
                        finish();
                    }
                }
            }
        });

        // Managing the back stack and keeping the database updated by manually handling the back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    Log.d("LoginActivity", "Back button pressed, but there is nothing to go back to.");
                } catch (Exception e) {
                    Log.e("LoginActivity", "Error: " + e.getMessage());
                }
            }
        });

        saveCredentials.setOnCheckedChangeListener((buttonView, isChecked) -> {
            /*
            Checkbox toggle for whether to save credentials during saveNewCredentials().
            When checked, current username and password are stored. When unchecked,
            stored username and password are made empty by setting their strings to "".
            The state of the checkbox is also saved in shared preferences for loading.
            */
            String username = usernameField.getText().toString().trim();
            String password = passwordField.getText().toString().trim();

            // Save or delete stored credentials depending on checkbox
            if (!isChecked){
                saveNewCredentials("", "", false);
            } else {
                saveNewCredentials(username, password, true);
            }
        });
    }

    public void CacheActivity(){
        Intent intent = new Intent (this, CacheListActivity.class);
        startActivity(intent);
    }

    private void saveNewCredentials(String username, String password, boolean checked) {
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putBoolean("checked", checked);

        if(checked) {
            editor.putString("username", username);
            editor.putString("password", password);
        } else {
            editor.putString("username", "");
            editor.putString("password", "");
        }
        editor.apply();
    }

    private void loadOldCredentials(){
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        String username = sharedPreferences.getString("username", "");
        String password = sharedPreferences.getString("password", "");
        boolean checked = sharedPreferences.getBoolean("checked", false);

        usernameField.setText(username);
        passwordField.setText(password);
        saveCredentials.setChecked(checked);
    }

    private void clearOldCredentials(){
        SharedPreferences sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("username");
        editor.remove("password");
        editor.remove("checked");
        editor.apply();
    }
}