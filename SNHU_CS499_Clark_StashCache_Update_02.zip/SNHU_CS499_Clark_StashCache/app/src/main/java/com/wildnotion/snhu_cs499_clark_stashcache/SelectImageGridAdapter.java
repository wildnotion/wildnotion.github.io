package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

public class SelectImageGridAdapter extends BaseAdapter {
    private Context context;
    private int[] drawableIDs;

    public SelectImageGridAdapter(Context context, int[] drawableIDs){
        this.context = context;
        this.drawableIDs = drawableIDs;
    }

    @Override
    public int getCount() {
        return drawableIDs.length;
    }

    @Override
    public Object getItem(int i) {
        return drawableIDs[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.image_select_item, viewGroup, false);

        }

        ImageView imageView = view.findViewById(R.id.grid_image);
        imageView.setImageResource(drawableIDs[i]);

        return view;
    }
}
