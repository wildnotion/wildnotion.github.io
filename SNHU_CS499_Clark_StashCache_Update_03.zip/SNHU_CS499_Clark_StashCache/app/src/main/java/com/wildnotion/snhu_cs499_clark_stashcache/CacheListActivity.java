package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CacheListActivity extends AppCompatActivity {
    // Singleton classes to manage database interaction with an authorized user
    SessionManager sessionManager;
    DatabaseManager databaseManager;

    // For displaying a list of caches stored in the SQLite Database
    private List<CacheModel> cacheModelList;

    // References for the buttons on the user interface
    Button createCacheButton; // To test activity switching
    Button logoutButton;

    Button optionsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cache_list);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        // Button assigning when loading the activity
        createCacheButton = findViewById(R.id.createCacheButton);
        logoutButton = findViewById(R.id.logoutButton);

        optionsButton = findViewById(R.id.optionsButton);

        // Accessing the session information to keep track of current user
        int sessionID = sessionManager.getUserId();
        //Toast.makeText(this, "Current Session: " + sessionID, Toast.LENGTH_SHORT).show();
        Log.d("CacheListActivity", "Current Session: " + sessionID);

        // Setting up the user interface for listing each cache
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Adding separation lines in the user interface recycler view
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        cacheModelList = databaseManager.getUserCaches();

        // The displayed UI elements for each cache are clickable, which when clicked will
        // lead to an associated inventory activity displaying all items in that cache
        SQLCacheViewAdapter sqlCacheViewAdapter = new SQLCacheViewAdapter(cacheModelList,
                position -> {
                    CacheModel cacheClicked = cacheModelList.get(position);
                    Log.d("CacheListActivity", "Clicked cache: " + cacheClicked.getName() + " ID: " + cacheClicked.getId());
                    try {
                        sessionManager.setCacheID(cacheClicked.getId());
                        InventoryActivity();
                        finish();
                    } catch (Error e) {
                        Log.e("CacheListActivity", "Cache not valid, database corrupt.");
                    }
                    //InventoryActivity();
                },
                databaseManager
        );
        recyclerView.setAdapter(sqlCacheViewAdapter);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Listen for button click
        createCacheButton.setOnClickListener(view -> {
            CreateCacheActivity();
            finish();
        });

        // Listen for button click
        logoutButton.setOnClickListener(view -> {
            sessionManager.logoutSession();
            LoginActivity();
            finish();
        });

        optionsButton.setOnClickListener(view -> {
            PermissionsActivity();
            //finish();
        });

        // Managing the back stack and keeping the database updated by manually handling the back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    Log.d("CacheListActivity", "Back button pressed, navigating to Login activity.");
                    sessionManager.logoutSession();
                    LoginActivity();
                    finish();
                } catch (Exception e) {
                    Log.e("CacheListActivity", "Error: " + e.getMessage());
                }
            }
        });

    }

    public void LoginActivity(){
        Intent intent = new Intent (this, LoginActivity.class);
        startActivity(intent);
    }

    public void CreateCacheActivity(){
        Intent intent = new Intent (this, CreateCacheActivity.class);
        startActivity(intent);
    }

    public void InventoryActivity(){
        Intent intent = new Intent (this, InventoryActivity.class);
        startActivity(intent);
    }

    public void PermissionsActivity(){
        Intent intent = new Intent (this, OptionsActivity.class);
        startActivity(intent);
    }
}