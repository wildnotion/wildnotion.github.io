package com.wildnotion.snhu_cs499_clark_stashcache;

// Methods and information for Caches stored in the SQLite database
public class CacheModel {
    private int id;
    private final int userId;
    private String name;
    private String hint;
    private double latitude;
    private double longitude;
    private int image;

    public CacheModel(int id, int userId, String name, String hint, double latitude, double longitude, int image){
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.hint = hint;
        this.latitude = latitude;
        this.longitude = longitude;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(float latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(float longitude) {
        this.longitude = longitude;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getUserId() {
        return userId;
    }
}
