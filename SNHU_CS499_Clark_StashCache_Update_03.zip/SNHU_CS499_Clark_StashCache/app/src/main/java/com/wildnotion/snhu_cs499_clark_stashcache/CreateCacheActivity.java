package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateCacheActivity extends AppCompatActivity implements GPSManager.GPSListener{
    // Singleton classes to manage database interaction with an authorized user
    SessionManager sessionManager;
    DatabaseManager databaseManager;

    private final int[] drawableCacheIDs = {
            R.drawable.location_snowy, R.drawable.location_overlook, R.drawable.location_desert,
            R.drawable.location_tavern, R.drawable.location_glade, R.drawable.location_crystal,
            R.drawable.location_basement, R.drawable.location_mushrooms, R.drawable.location_shipwreck
    };

    private int chosenImageIndex = 1; // Sets the default image index to 1, the second position in the grid

    private GPSManager gpsManager;

    Button backButton;
    Button createButton;
    Button gpsButton;
    EditText etName;
    EditText etHint;
    EditText etLatitude;
    EditText etLongitude;
    ImageView ivCache;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_cache);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        // GPS initialization when given permissions
        gpsManager = new GPSManager(this, this);

        backButton = findViewById(R.id.backButton);
        createButton = findViewById(R.id.createButton);
        gpsButton = findViewById(R.id.gpsButton);
        etName = findViewById(R.id.etName);
        etHint = findViewById(R.id.etHint);
        etLatitude = findViewById(R.id.etLatitude);
        etLongitude = findViewById(R.id.etLongitude);
        ivCache = findViewById(R.id.ivCache);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        int sessionID = sessionManager.getUserId();
        Toast.makeText(this, "Current Session: " + sessionID, Toast.LENGTH_SHORT).show();

        ivCache.setOnClickListener(view -> displayImageGrid());

        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Only allow the create button to be clicked when a name is entered
                createButton.setEnabled(!charSequence.toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        // Listen for button click
        backButton.setOnClickListener(view -> {
            CacheListActivity();
            finish();
        });

        // Listen for button click
        createButton.setOnClickListener(view -> {
            int id = 0;
            int userId = sessionManager.getUserId();
            String name = etName.getText().toString();
            String hint = etHint.getText().toString();
            String latitudeString = etLatitude.getText().toString();
            String longitudeString = etLongitude.getText().toString();
            float latitude = 0.0F;
            float longitude = 0.0F;

            try {
                latitude = Float.parseFloat(latitudeString);
            } catch (NumberFormatException exception) {
                Log.e("CreateCacheActivity", exception.toString());
                //Toast.makeText(CreateCacheActivity.this, "Improper float for latitude.", Toast.LENGTH_SHORT).show();
            }

            try {
                longitude = Float.parseFloat(longitudeString);
            } catch (NumberFormatException exception) {
                Log.e("CreateCacheActivity", exception.toString());
                //Toast.makeText(CreateCacheActivity.this, "Improper float for longitude.", Toast.LENGTH_SHORT).show();
            }

            Log.d("CreateCacheActivity", "Chosen image ID: " + chosenImageIndex);

            if (chosenImageIndex < 0 || chosenImageIndex >= drawableCacheIDs.length){
                chosenImageIndex = 0; // If the image ID falls out of bounds, reset it to 0
            }

            boolean isNewCacheCreated = databaseManager.createNewCache(new CacheModel(id ,userId, name, hint, latitude, longitude, chosenImageIndex));

            if (isNewCacheCreated) {
                Toast.makeText(CreateCacheActivity.this, "Created a cache.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(CreateCacheActivity.this, "Failed to create a cache.", Toast.LENGTH_SHORT).show();
            }
            CacheListActivity();
            finish();
        });

        // Listen for button click
        gpsButton.setOnClickListener(view -> {
            // FIXME: Populate the latitude and longitude with current GPS data
            Location lastKnownLocation = gpsManager.getLastKnownLocation();
            if (lastKnownLocation != null) {
                etLatitude.setText(String.valueOf(lastKnownLocation.getLatitude()));
                etLongitude.setText(String.valueOf(lastKnownLocation.getLongitude()));
            }

            gpsManager.getCurrentLocation();
        });

        // Managing the back stack and keeping the database updated by manually handling the back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            public void handleOnBackPressed() {
                try {
                    Log.d("CreateCacheActivity", "Back button pressed, navigating to the Cache List activity.");
                    CacheListActivity();
                    finish();
                } catch (Exception e) {
                    Log.e("CreateCacheActivity", "Error: " + e.getMessage());
                }
            }
        });
    }

    public void CacheListActivity(){
        Intent intent = new Intent (this, CacheListActivity.class);
        startActivity(intent);
    }

    private void displayImageGrid(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose");

        View image_select_grid = getLayoutInflater().inflate(R.layout.image_select_grid, null);
        GridView gridView = image_select_grid.findViewById(R.id.gridView);

        SelectImageGridAdapter adapter = new SelectImageGridAdapter(this, drawableCacheIDs);
        gridView.setAdapter(adapter);

        builder.setView(image_select_grid);

        AlertDialog dialog = builder.create();
        dialog.show();

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            chosenImageIndex = position;
            ivCache.setImageResource(drawableCacheIDs[chosenImageIndex]);
            dialog.dismiss();
        });
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        gpsManager.cancelLocationUpdates();
    }

    @Override
    public void onLocationUpdated(double latitude, double longitude, float accuracy){
        runOnUiThread(()-> {
            etLatitude.setText(String.format("%.6f", latitude));
            etLongitude.setText(String.format("%.6f", longitude));
        });
    }
}