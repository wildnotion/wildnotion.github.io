package com.wildnotion.snhu_cs499_clark_stashcache;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseManager extends SQLiteOpenHelper {
    // For keeping track of the logged in user
    private final SessionManager sessionManager = SessionManager.getSession();

    //Singleton pattern here (private static instance, private constructor, method to get/create)
    private static DatabaseManager database;


    private DatabaseManager(Context context){
        super(context.getApplicationContext(), DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized DatabaseManager getDatabase(Context context){
        if (database == null) {
            Log.d("DatabaseManager", "Creating a new Database Manager");
            database = new DatabaseManager(context.getApplicationContext());
        } else {
            Log.d("DatabaseManager", "Getting an old Database Manager");
        }
        return  database;
    }

    // Database name, version, and instance declarations
    private static final String DATABASE_NAME = "StashCache.db";
    private static final int DATABASE_VERSION = 1;


    // Username and password table
    private static final String USER_TABLE = "USER_TABLE";
    private static final String COLUMN_USER_ID = "ID";
    private static final String COLUMN_USER_NAME = "USERNAME";
    private static final String COLUMN_USER_PASS = "PASSWORD";

    // Individual cache table
    private static final String CACHE_TABLE = "CACHE_TABLE";
    private static final String COLUMN_CACHE_ID = "ID";
    private static final String COLUMN_CACHE_USER_ID = "USER_ID";
    private static final String COLUMN_CACHE_NAME = "NAME";
    private static final String COLUMN_CACHE_HINT = "HINT";
    private static final String COLUMN_CACHE_LATITUDE = "LATITUDE";
    private static final String COLUMN_CACHE_LONGITUDE = "LONGITUDE";
    private static final String COLUMN_CACHE_IMAGE = "IMAGE";

    // Individual item table
    private static final String ITEM_TABLE = "ITEM_TABLE";
    private static final String COLUMN_ITEM_ID = "ID";
    private static final String COLUMN_ITEM_CACHE_ID = "CACHE_ID";
    private static final String COLUMN_ITEM_NAME = "NAME";
    private static final String COLUMN_ITEM_DESCRIPTION = "DESCRIPTION";
    private static final String COLUMN_ITEM_COUNT = "COUNT";
    private static final String COLUMN_ITEM_IMAGE = "IMAGE";

    // Necessary override of the extended SQLiteOpenHelper
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Create a master username password table
        String createMasterUserPassTable = "CREATE TABLE " + USER_TABLE + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_NAME + " TEXT NOT NULL UNIQUE, "
                + COLUMN_USER_PASS + " TEXT NOT NULL);";
        sqLiteDatabase.execSQL(createMasterUserPassTable);

        // Create a master cache table
        String createMasterCacheTable = "CREATE TABLE " + CACHE_TABLE + " (" +
                COLUMN_CACHE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_CACHE_USER_ID + " INTEGER NOT NULL, " +
                COLUMN_CACHE_NAME + " TEXT NOT NULL, " +
                COLUMN_CACHE_HINT + " TEXT, " +
                COLUMN_CACHE_LATITUDE + " REAL, " +
                COLUMN_CACHE_LONGITUDE + " REAL, " +
                COLUMN_CACHE_IMAGE + " INTEGER, " +
                "FOREIGN KEY(" + COLUMN_CACHE_USER_ID + ") REFERENCES " +
                USER_TABLE + "(" + COLUMN_USER_ID + ") ON DELETE CASCADE);";
        sqLiteDatabase.execSQL(createMasterCacheTable);

        // Create a master item table
        String createMasterItemTable = "CREATE TABLE " + ITEM_TABLE + " (" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_CACHE_ID + " INTEGER NOT NULL, " +
                COLUMN_ITEM_NAME + " TEXT NOT NULL, " +
                COLUMN_ITEM_DESCRIPTION + " TEXT, " +
                COLUMN_ITEM_COUNT + " INTEGER, " +
                COLUMN_ITEM_IMAGE + " INTEGER, " +
                "FOREIGN KEY(" + COLUMN_ITEM_CACHE_ID + ") REFERENCES " +
                CACHE_TABLE + "(" + COLUMN_CACHE_ID + ") ON DELETE CASCADE);";
        sqLiteDatabase.execSQL(createMasterItemTable);
    }

    // Necessary override of the extended SQLiteOpenHelper
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        // FIXME Replace current destroy-everything with alter-everything for tables
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + CACHE_TABLE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + ITEM_TABLE);
        this.onCreate(sqLiteDatabase);
    }

    public boolean createNewUser(UserPassModel userPassModel){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //contentValues.put(COLUMN_USER_ID, userPassModel.getId());
        contentValues.put(COLUMN_USER_NAME, userPassModel.getUsername());
        contentValues.put(COLUMN_USER_PASS, userPassModel.getPassword());

        long result = sqLiteDatabase.insert(USER_TABLE, null, contentValues);

        sqLiteDatabase.close();

        // FIXME: Add better error handling
        return result != -1;
    }


    public boolean createNewCache(CacheModel cacheModel){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLUMN_CACHE_USER_ID, cacheModel.getUserId());
        contentValues.put(COLUMN_CACHE_NAME, cacheModel.getName());
        contentValues.put(COLUMN_CACHE_HINT, cacheModel.getHint());
        contentValues.put(COLUMN_CACHE_LATITUDE, cacheModel.getLatitude());
        contentValues.put(COLUMN_CACHE_LONGITUDE, cacheModel.getLongitude());
        contentValues.put(COLUMN_CACHE_IMAGE, cacheModel.getImage());

        long result = sqLiteDatabase.insert(CACHE_TABLE, null, contentValues);

        if (result != -1){
            cacheModel.setId((int) result);
            Log.d("DatabaseManager", "Cache created with ID: " + cacheModel.getId());
            sqLiteDatabase.close();
            return true;
        } else {
            Log.d("DatabaseManager", "No cache created.");
            sqLiteDatabase.close();
            return false;
        }
    }

    public boolean addItemToCache(ItemModel itemModel){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        //contentValues.put(COLUMN_ITEM_ID, itemModel.getId());
        contentValues.put(COLUMN_ITEM_CACHE_ID, itemModel.getCacheId());
        contentValues.put(COLUMN_ITEM_NAME, itemModel.getName());
        contentValues.put(COLUMN_ITEM_DESCRIPTION, itemModel.getDescription());
        contentValues.put(COLUMN_ITEM_COUNT, itemModel.getCount());
        contentValues.put(COLUMN_ITEM_IMAGE, itemModel.getImage());

        long result = sqLiteDatabase.insert(ITEM_TABLE, null, contentValues);

        if (result != -1){
            itemModel.setId((int) result);
            Log.d("DatabaseManager", "Item added with ID: " + itemModel.getId());
            sqLiteDatabase.close();
            return  true;
        } else {
            Log.d("DatabaseManager", "Item had a result of: " + result);
            sqLiteDatabase.close();
            return false;
        }
    }

    public List<CacheModel> getUserCaches(){
        List<CacheModel> userCaches = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        int sessionID = sessionManager.getUserId();

        String sqlQuery = "SELECT * FROM " + CACHE_TABLE + " WHERE " + COLUMN_CACHE_USER_ID + " = ?";
        Cursor cursor = sqLiteDatabase.rawQuery(sqlQuery, new String[]{String.valueOf(sessionID)});

        try {
            if (cursor.moveToFirst()) {
                do {
                    // FIXME Add better null checks
                    int cacheID = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_ID));
                    int cacheUserID = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_USER_ID));
                    String cacheName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_NAME));
                    String cacheHint = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_HINT));
                    float cacheLatitude = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_CACHE_LATITUDE));
                    float cacheLongitude = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_CACHE_LONGITUDE));
                    int cacheImage = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_IMAGE));
                    userCaches.add(new CacheModel(cacheID, cacheUserID, cacheName, cacheHint, cacheLatitude, cacheLongitude, cacheImage));
                } while (cursor.moveToNext());
            }
        } catch (Exception e){
            Log.e("DatabaseManager", "Unknown Exception");
        }

        /*
        public CacheModel(int id, int userId, String name, String hint, float latitude, float longitude, int image)
            private int id;
    private int userId;
    private String name;
    private String hint;
    private float latitude;
    private float longitude;
    private int image;
         */

        cursor.close();
        sqLiteDatabase.close();
        return userCaches;
    }

    public List<ItemModel> getCurrentCacheItems(int cacheID){
        List<ItemModel> cacheItems = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        String sqlQuery = "SELECT * FROM " + ITEM_TABLE + " WHERE " + COLUMN_ITEM_CACHE_ID + " = ?";
        Cursor cursor = sqLiteDatabase.rawQuery(sqlQuery, new String[]{String.valueOf(cacheID)});

        try {
            Log.d("Database Manager", "Query for cacheID: " + cacheID);
            if (cursor.moveToFirst()) {
                do {
                    int id = Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)));
                    String itemName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                    String itemDescription = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_DESCRIPTION));
                    int itemCount = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_COUNT));
                    int itemImage = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_IMAGE));
                    cacheItems.add(new ItemModel(id, cacheID, itemName, itemDescription, itemCount, itemImage));
                } while (cursor.moveToNext());
            } else {
                Log.d("Database Manager", "No items in cacheID: " + cacheID);
            }
        } catch (Exception e){
            Log.e("Database Manager", "Unknown error during Query.");
        }

        cursor.close();
        sqLiteDatabase.close();
        return cacheItems;
    }

    public UserPassModel getUsernameID(String username){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.query(USER_TABLE, new String[] { COLUMN_USER_ID, COLUMN_USER_NAME,
                        COLUMN_USER_PASS }, COLUMN_USER_NAME + "=?", new String[] { username },
                null, null, null);

        if (cursor.moveToFirst()) {
            @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
            @SuppressLint("Range") String password = cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASS));
            cursor.close();
            sqLiteDatabase.close();
            UserPassModel userPassModel = new UserPassModel(username, password);
            userPassModel.setId(id);
            return userPassModel;
        }

        cursor.close();
        sqLiteDatabase.close();
        return null;
    }

    public boolean deleteCacheById(int cacheID) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        int userID = sessionManager.getUserId();
        Log.d("DatabaseManager", "DB-MAN Trying to delete cache ID: " + cacheID + " from user ID: " + userID);

        int success = sqLiteDatabase.delete(CACHE_TABLE, COLUMN_CACHE_ID + " = ? AND " +
                COLUMN_CACHE_USER_ID + " = ?", new String[]{String.valueOf(cacheID), String.valueOf(userID)});

        if (success > 0) {
            Log.d("DatabaseManager", "Deleted cache " + cacheID);
        } else {
            Log.d("DatabaseManager", "Cache " + cacheID + " was not deleted...");
        }

        sqLiteDatabase.close();

        return success > 0;
    }

    public boolean deleteItemByID(int itemID) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        int userID = sessionManager.getUserId();
        int cacheID = sessionManager.getCacheID();
        Log.d("DatabaseManager", "DB-MAN Trying to delete item ID: " + itemID + " from cache ID: " + cacheID + " assigned to user ID: " + userID);

        boolean success = false;
        try {
            sqLiteDatabase.beginTransaction();

            int confirmDelete = sqLiteDatabase.delete(ITEM_TABLE,
                    COLUMN_ITEM_ID + " = ? AND " + COLUMN_ITEM_CACHE_ID + " = ?",
                                new String[]{String.valueOf(itemID), String.valueOf(cacheID)});

            if (confirmDelete > 0) {
                Log.d("DatabaseManager", "Deleted item #:" + itemID + " from cache #:" + cacheID);
                success = true;
            } else {
                Log.d("DatabaseManager", "Item #:" + itemID + " was not deleted from cache #:" + cacheID);
            }

            sqLiteDatabase.setTransactionSuccessful();
        } catch (Exception e) {
            Log.e("DatabaseManager", "Error: " + e.getMessage());
        }

        sqLiteDatabase.endTransaction();
        sqLiteDatabase.close();

        return success;
    }

    public void deleteActiveUser(){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        int userID = sessionManager.getUserId();
        Log.d("DatabaseManager", "Trying to delete user ID: " + userID);

        int success = sqLiteDatabase.delete(USER_TABLE, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(userID)});

        if (success > 0) {
            //FIXME: Remove any stored username and password in shared preferences at the same time
            Log.d("DatabaseManager", "Deleted user " + userID);
        } else {
            Log.d("DatabaseManager", "User " + userID + " was not deleted...");
        }

        sqLiteDatabase.close();
    }

    public CacheModel getCacheById(int cacheID) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        CacheModel cacheModel = null;

        String sqlQuery = "SELECT * FROM " + CACHE_TABLE + " WHERE " + COLUMN_CACHE_ID + " = ?";
        Cursor cursor = sqLiteDatabase.rawQuery(sqlQuery, new String[]{String.valueOf(cacheID)});

        try{
            Log.d("Database Manager", "Get cache query for cacheID: " + cacheID);
            if (cursor.moveToFirst()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_ID));
                int userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_USER_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_NAME));
                String hint = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_HINT));
                float latitude = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_LATITUDE));
                float longitude = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_LONGITUDE));
                int image = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_IMAGE));

                cacheModel = new CacheModel(id, userId, name, hint, latitude, longitude, image);
            } else {
                Log.d("Database Manager", "No cache with ID: " + cacheID);
            }
        } catch (Exception e) {
            Log.e("DatabaseManager", "Unknown exception");
        }

        cursor.close();
        sqLiteDatabase.close();

        return cacheModel;
    }
}
