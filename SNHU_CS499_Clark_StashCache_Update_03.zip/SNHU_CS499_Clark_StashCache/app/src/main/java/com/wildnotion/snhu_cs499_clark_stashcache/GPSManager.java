package com.wildnotion.snhu_cs499_clark_stashcache;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Looper;
import android.util.Log;

import androidx.core.content.ContextCompat;

public class GPSManager {
    public double latitude;
    public double longitude;
    public float accuracy;

    private final LocationManager locationManager;
    private LocationListener locationListener;
    private final Context context;
    private final GPSListener gpsListener;

    public interface GPSListener {
        void onLocationUpdated(double latitude, double longitude, float accuracy);
    }

    public GPSManager(Context context, GPSListener listener){
        this.context = context;
        this.locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        this.gpsListener = listener;
    }

    // Returns the last known location for populating a quick string on the layout,
    // with a more accurate reading to follow from getCurrentLocation
    public Location getLastKnownLocation(){
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){
            return locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        }
        return null;
    }

    // Returns the current location, and stops requesting updates after a certain
    // accuracy is reached to conserve battery life
    // FIXME: remove debug logs before release
    public void getCurrentLocation(){
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){

            locationListener = location -> {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                accuracy = location.getAccuracy();
                Log.d("GPSManager", "Lat: " + latitude + ", Lon:" + longitude + ", Acc: " + accuracy + "%");

                if(gpsListener != null){
                    gpsListener.onLocationUpdated(latitude, longitude, accuracy);
                }

                if (accuracy < 20) {
                    Log.d("GPSManager", "Cancelling the updates.");
                    cancelLocationUpdates();
                }
            };

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,
                    locationListener, Looper.getMainLooper());
        } else {
            Log.d("GPSManager", "Permission not granted for GPS.");
        }
    }

    // Stops using the GPS sensor to find the current location
    public void cancelLocationUpdates() {
        if(locationListener != null){
            locationManager.removeUpdates(locationListener);
        }
    }
}
