package com.wildnotion.snhu_cs499_clark_stashcache;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class OptionsActivity extends AppCompatActivity {
    // Singleton classes to manage database interaction with an authorized user
    SessionManager sessionManager;
    DatabaseManager databaseManager;

    Button locationButton;
    TextView tvStatus;
    Button backButton;
    Button deleteActiveUserButton;

    private static final int LOCATION_PERMISSION_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_options);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        locationButton = findViewById(R.id.locationButton);
        tvStatus = findViewById(R.id.tvStatus);
        backButton = findViewById(R.id.backButton);
        deleteActiveUserButton = findViewById(R.id.deleteActiveUserButton);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        int sessionID = sessionManager.getUserId();
        Toast.makeText(this, "Current Session: " + sessionID, Toast.LENGTH_SHORT).show();

        // Set layout status text to current location permission status
        updateLocationStatus();

        // Listen for button click
        locationButton.setOnClickListener(view -> ToggleLocationPermissions()); // toggles the permissions for the location services

        // Listen for button click
        backButton.setOnClickListener(view -> finish()); // returns the user to whichever activity brought them here

        deleteActiveUserButton.setOnClickListener(view -> new AlertDialog.Builder(this)
                .setTitle("Delete active user account?")
                .setMessage("Are you sure you want to delete this active user account?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    // FIXME: Reset the shared preference data, so that saved information
                    //  is set to empty (i.e., username, password, checkbox selection)
                    databaseManager.deleteActiveUser();
                    LoginActivity();
                    finish();
                })
                .setNegativeButton("No", null)
                .show());
    }

    // Upon clicking the locations button on the layout when the current status is denied, the Android
    // location permissions pop-up appears for a user to select from, and when the current status is
    // granted, an alert message appears with a redirect to the application's settings to revoke permissions
    public void ToggleLocationPermissions(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {

            new AlertDialog.Builder(this)
                            .setTitle("Deny location permissions?")
                            .setMessage("Location permissions are currently granted. Would you like to deny location permissions?" +
                                    "\n(Requires manually updating the 'Permissions' in 'App info'.)")
                                    .setPositiveButton("Yes", (dialog, which) -> {
                                        // Open app settings
                                        Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                        intent.setData(Uri.parse("package:" + getPackageName()));
                                        startActivity(intent);
                                    })
                                    .setNegativeButton("No", null)
                                    .show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_CODE);
        }
        updateLocationStatus();
    }

    // The permission status for the location services is displayed
    private void updateLocationStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            tvStatus.setText(R.string.granted);
        } else {
            tvStatus.setText(R.string.denied);
        }
    }

    // After deleting an active user account, the user is sent back to the login activity
    public void LoginActivity(){
        Intent intent = new Intent (this, LoginActivity.class);
        startActivity(intent);
    }
}