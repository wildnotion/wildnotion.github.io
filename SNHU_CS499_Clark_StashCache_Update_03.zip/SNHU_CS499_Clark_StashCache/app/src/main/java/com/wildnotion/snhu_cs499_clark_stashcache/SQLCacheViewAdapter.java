package com.wildnotion.snhu_cs499_clark_stashcache;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SQLCacheViewAdapter extends RecyclerView.Adapter<SQLCacheViewAdapter.SQLViewHolder> {
    private final List<CacheModel> cacheModelList;
    private final OnCacheClickListener cacheListener; // For clicking on caches

    private final int[] drawableCacheIDs = {
            R.drawable.location_snowy, R.drawable.location_overlook, R.drawable.location_desert,
            R.drawable.location_tavern, R.drawable.location_glade, R.drawable.location_crystal,
            R.drawable.location_basement, R.drawable.location_mushrooms, R.drawable.location_shipwreck
    };

    // Singleton classes to manage database interaction with an authorized user
    // SessionManager sessionManager;
    DatabaseManager databaseManager;

    public interface OnCacheClickListener {
        void onCacheClick(int position);
    }

    public SQLCacheViewAdapter(List<CacheModel> cacheModelList, OnCacheClickListener cacheListener, DatabaseManager databaseManager) {
        this.cacheModelList = cacheModelList;
        this.cacheListener = cacheListener;
        this.databaseManager = databaseManager;
    }

    @NonNull
    @Override
    public SQLViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_cache, parent, false);
        return new SQLViewHolder(view);
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onBindViewHolder(@NonNull SQLViewHolder holder, int position) {
        CacheModel cacheModel = cacheModelList.get(position);

        holder.tvName.setText(cacheModel.getName());
        holder.tvHint.setText(cacheModel.getHint());
        holder.tvLatitude.setText(String.valueOf(cacheModel.getLatitude()));
        holder.tvLongitude.setText(String.valueOf(cacheModel.getLongitude()));
        holder.ivCacheImage.setImageResource(drawableCacheIDs[cacheModel.getImage()]);

        // FIXME clarifying comments
        holder.ivDeleteCache.setOnClickListener(view -> {
            int cacheID = cacheModel.getId();
            deleteCache(cacheID);
            cacheModelList.remove(position);
            notifyItemRemoved(position);

            // Once the list is empty, ensures Recycler view updates correctly
            if (cacheModelList.isEmpty()){
                notifyDataSetChanged();
            } else {
                notifyItemRangeChanged(position, cacheModelList.size());
            }
        });

        holder.itemView.setOnClickListener(view -> {
            if (cacheListener != null) {
                cacheListener.onCacheClick(position);
            }
        });
    }

    private void deleteCache(int cacheID) {
        int userID = SessionManager.getSession().getUserId();

        Log.d("SQLCacheViewAdapter", "Trying to delete cacheID: " + cacheID + " from userID" + userID);

        boolean success = databaseManager.deleteCacheById(cacheID);
        if (success){
            Log.d("SQLCacheViewAdapter", String.format("%d Deleted from %d", cacheID, userID));
        } else {
            Log.d("SQLCacheViewAdapter", "Nothing deleted");
        }
    }

    @Override
    public int getItemCount() {
        //FIXME Add clarifying comments from Android IDE auto help
        return cacheModelList != null ? cacheModelList.size() : 0;
    }

    public static class SQLViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        TextView  tvHint;
        TextView tvLatitude;
        TextView tvLongitude;
        ImageView ivCacheImage;
        ImageView ivDeleteCache;

        public SQLViewHolder(@NonNull View cacheView) {
            super(cacheView);
            tvName = cacheView.findViewById(R.id.tvName);
            tvHint = cacheView.findViewById(R.id.tvHint);
            tvLatitude = cacheView.findViewById(R.id.tvLatitude);
            tvLongitude = cacheView.findViewById(R.id.tvLongitude);
            ivCacheImage = cacheView.findViewById(R.id.ivCacheImage);
            ivDeleteCache = cacheView.findViewById(R.id.ivDeleteCache);
        }
    }
}
