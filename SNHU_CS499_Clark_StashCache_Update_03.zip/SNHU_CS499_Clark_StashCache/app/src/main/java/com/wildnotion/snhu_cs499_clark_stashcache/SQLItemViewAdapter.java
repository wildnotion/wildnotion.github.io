package com.wildnotion.snhu_cs499_clark_stashcache;

import android.annotation.SuppressLint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SQLItemViewAdapter extends RecyclerView.Adapter<SQLItemViewAdapter.SQLViewHolder> {
    private final List<ItemModel> itemModelList;
    private final OnItemClickListener itemListener; // For clicking on items

    private final int[] drawableItemIDs = {
            R.drawable.item_coin, R.drawable.item_candy, R.drawable.item_dairy,
            R.drawable.item_jewelry, R.drawable.item_eggs, R.drawable.item_sock,
            R.drawable.item_scissors, R.drawable.item_lens, R.drawable.item_keys
    };

    // Singleton classes to manage database interaction with an authorized user
    SessionManager sessionManager;
    DatabaseManager databaseManager;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public SQLItemViewAdapter(List<ItemModel> itemModelList, OnItemClickListener itemListener,
                              DatabaseManager databaseManager) {
        this.itemModelList = itemModelList;
        this.itemListener = itemListener;
        this.databaseManager = databaseManager;
    }

    @NonNull
    @Override
    public SQLViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new SQLViewHolder(view);
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onBindViewHolder(@NonNull SQLViewHolder holder, int position) {
        ItemModel itemModel = itemModelList.get(position);
        //onBindViewHolder = Log.d("onBindViewHolder", "Item ID: " + itemModel.getId() + ", Name: " + itemModel.getName());

        holder.tvName.setText(itemModel.getName());
        holder.tvDescription.setText(itemModel.getDescription());
        holder.tvCount.setText(String.valueOf(itemModel.getCount()));
        holder.ivSelectedImage.setImageResource(drawableItemIDs[itemModel.getImage()]);

        // FIXME clarifying comments
        holder.ivDeleteImage.setOnClickListener(view -> {
            int itemID = itemModel.getId();
            // FIXME Debug remove
            Log.d("SQLiteViewAdapter", "Item id = " + itemID);

            // Call the method below to delete the current item ID
            deleteItem(itemID, position);

            // Once the list is empty, ensures Recycler view updates correctly
            if (itemModelList.isEmpty()){
                notifyDataSetChanged();
            } else {
                notifyItemRangeChanged(itemID, itemModelList.size());
            }
        });

        holder.itemView.setOnClickListener(view -> {
            if (itemListener != null) {
                itemListener.onItemClick(position);
            }
        });


    }

    @Override
    public int getItemCount() {
        //FIXME Explain better
        return itemModelList != null ? itemModelList.size() : 0;
    }

    @SuppressLint("NotifyDataSetChanged")
    private void deleteItem(int itemID, int position) {
        // FIXME Debug remove
        int cacheID = -1;

        if(sessionManager != null){
            cacheID = SessionManager.getSession().getCacheID();
        }

        Log.d("SQLItemViewAdapter", "SQL-IVA: Trying to delete item ID: " + itemID + " from cache ID: " + cacheID);

        boolean success = databaseManager.deleteItemByID(itemID);

        // FIXME Debug remove/adjust
        if (success){
            Log.d("SQLItemViewAdapter", String.format("%d Deleted from %d", itemID, cacheID));
            if(position >= 0 && position < itemModelList.size()){
                itemModelList.remove(position);
                notifyItemRemoved(position);
                notifyItemChanged(position, itemModelList.size() - position);
            }
        } else {
            Log.d("SQLItemViewAdapter", "Nothing deleted");
        }

        // Once the list is empty, ensures Recycler view updates correctly
        if (itemModelList.isEmpty()){
            notifyDataSetChanged();
        } else {
            // FIXME detail
            notifyItemRangeChanged(itemID, itemModelList.size() - position);
        }
    }

    public static class SQLViewHolder extends RecyclerView.ViewHolder {
        TextView tvCacheName;
        TextView tvCacheHint;
        TextView tvLatitude;
        TextView tvLongitude;

        TextView tvName;
        TextView tvDescription;
        TextView tvCount;

        ImageView ivSelectedImage;
        ImageView ivDeleteImage;
        ImageView ivCacheImage;

        public SQLViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCacheName = itemView.findViewById(R.id.tvCacheName);
            tvCacheHint = itemView.findViewById(R.id.tvCacheHint);
            tvLatitude = itemView.findViewById(R.id.tvLatitude);
            tvLongitude = itemView.findViewById(R.id.tvLongitude);
            ivCacheImage = itemView.findViewById(R.id.ivCacheImage);

            tvName = itemView.findViewById(R.id.tvName);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvCount = itemView.findViewById(R.id.tvCount);
            ivSelectedImage = itemView.findViewById(R.id.ivSelectedImage);
            ivDeleteImage = itemView.findViewById(R.id.ivDeleteImage);
        }
    }
}
