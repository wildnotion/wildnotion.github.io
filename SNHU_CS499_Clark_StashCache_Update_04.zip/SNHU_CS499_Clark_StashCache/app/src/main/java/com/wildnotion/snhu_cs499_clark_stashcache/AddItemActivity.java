package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// For adding Items to a specific Cache associated with one User
public class AddItemActivity extends AppCompatActivity {
    // Singleton classes for managing database interaction with an authorized user
    SessionManager sessionManager;
    DatabaseManager databaseManager;

    // The current item image displayed on the layout
    private int chosenImageIndex = 0;

    // List of images from the drawable res folder to generate on a pop-up grid layout
    // after clicking the current item image
    private final int[] drawableItemIDs = {
            R.drawable.item_coin, R.drawable.item_candy, R.drawable.item_dairy,
            R.drawable.item_jewelry, R.drawable.item_eggs, R.drawable.item_sock,
            R.drawable.item_scissors, R.drawable.item_lens, R.drawable.item_keys
    };

    //Cache to add items to
    int cacheID;

    //Connections to the fields on the layout
    Button backButton;
    Button addButton;
    EditText etName;
    EditText etDescription;
    EditText etCount;
    ImageView ivItem;


    // The onCreate method runs once the activity is called, initializing variables to access
    // a specific cache, setting up and displaying the appropriate user interface, and assigning
    // listeners to the clickable buttons & fields to respond to input.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        try {
            cacheID = sessionManager.getCacheID();
        } catch (Exception e) {
            Log.d("AddItemActivity", "");
            cacheID = -1;
        }

        backButton = findViewById(R.id.backButton);
        addButton = findViewById(R.id.addButton);
        etName = findViewById(R.id.etName);
        etDescription = findViewById(R.id.etDescription);
        etCount = findViewById(R.id.etCount);
        ivItem = findViewById(R.id.ivItem);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Allows the "Add Item" button to be clickable when the edit text "Name" field is not empty
        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                addButton.setEnabled(!charSequence.toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        // Opens a 3x3 image grid to select images from a drawableItemIDs list
        ivItem.setOnClickListener(view -> displayImageGrid());

        // Sets the function of the back button to return to the Inventory activity,
        // which ensures the database is kept up to date
        backButton.setOnClickListener(view -> {
            InventoryActivity();
            finish();
        });

        // Creates a new entry in the database for an item associated with the active cache ID
        addButton.setOnClickListener(view -> {
            int id = 0;
            int cacheId = sessionManager.getCacheID();
            String name = etName.getText().toString().trim();
            String description = etDescription.getText().toString().trim();
            String countString = etCount.getText().toString();
            int count = 0;

            if (!countString.isEmpty()){
                try{
                    count = Integer.parseInt(countString);
                }catch(NumberFormatException ignored){
                }
            }

            if (chosenImageIndex < 0 || chosenImageIndex >= drawableItemIDs.length){
                // If a corrupted image ID falls out of bounds, it is reset to 0 to prevent errors
                chosenImageIndex = 0;
            }

            // A new item is added to the database for the associated cache,
            // using the variables input on the layout
            databaseManager.addItemToCache(new ItemModel(id , cacheId, name, description,
                    count, chosenImageIndex));

            InventoryActivity();
            finish();
        });

        // Managing the back stack and keeping the database updated by manually handling the back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    Log.d("AddItemActivity", "Back button pressed, navigating to Inventory activity.");
                    InventoryActivity();
                    finish();
                } catch (Exception e) {
                    Log.e("AddItemActivity", "Error: " + e.getMessage());
                }
            }
        });
    }


    // To switch between activities
    public void InventoryActivity(){
        Intent intent = new Intent (this, InventoryActivity.class);
        startActivity(intent);
    }

    // To select an image from a pop-up grid that will be saved as a reference for the associated item
    private void displayImageGrid(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose");

        View image_select_grid = getLayoutInflater().inflate(R.layout.image_select_grid, null);
        GridView gridView = image_select_grid.findViewById(R.id.gridView);

        SelectImageGridAdapter adapter = new SelectImageGridAdapter(this, drawableItemIDs);
        gridView.setAdapter(adapter);

        builder.setView(image_select_grid);

        AlertDialog dialog = builder.create();
        dialog.show();

        // Once the image on the grid is clicked the reference to be saved
        // for the item is updated and the pop-up grid is closed
        gridView.setOnItemClickListener((parent, view, position, id) -> {
            chosenImageIndex = position;
            ivItem.setImageResource(drawableItemIDs[chosenImageIndex]);
            dialog.dismiss();
        });
    }
}