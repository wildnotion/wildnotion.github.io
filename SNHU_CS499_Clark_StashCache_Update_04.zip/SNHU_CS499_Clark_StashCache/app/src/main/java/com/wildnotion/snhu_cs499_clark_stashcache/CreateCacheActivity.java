package com.wildnotion.snhu_cs499_clark_stashcache;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// For creating a Cache to store Items for a logged in User
public class CreateCacheActivity extends AppCompatActivity implements GPSManager.GPSListener, GPSManager.GPSFetchCallback{
    // Singleton classes to manage database interaction with an authorized user
    SessionManager sessionManager;
    DatabaseManager databaseManager;

    // List of drawable images to populate the grid for a user to choose
    private final int[] drawableCacheIDs = {
            R.drawable.location_snowy, R.drawable.location_overlook, R.drawable.location_desert,
            R.drawable.location_tavern, R.drawable.location_glade, R.drawable.location_crystal,
            R.drawable.location_basement, R.drawable.location_mushrooms, R.drawable.location_shipwreck
    };

    // Sets the default image index to 1, the second image on the grid being the overlook
    // Just a personal preference for a default image
    private int chosenImageIndex = 1;

    private GPSManager gpsManager;

    Button backButton;
    Button createButton;
    Button gpsButton;
    EditText etName;
    EditText etHint;
    EditText etLatitude;
    EditText etLongitude;
    ImageView ivCache;
    ProgressBar progressBarGPS;
    TextView tvStatusGPSProgressBar;

    boolean gpsEnabled = false;
    boolean fetchingGPS = false;

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_cache);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        // GPS initialization when given permissions
        gpsManager = new GPSManager(this, this, this);
        gpsEnabled = gpsManager.gpsEnabled();

        backButton = findViewById(R.id.backButton);
        createButton = findViewById(R.id.createButton);
        gpsButton = findViewById(R.id.gpsButton);
        etName = findViewById(R.id.etName);
        etHint = findViewById(R.id.etHint);
        etLatitude = findViewById(R.id.etLatitude);
        etLongitude = findViewById(R.id.etLongitude);
        ivCache = findViewById(R.id.ivCache);
        progressBarGPS = findViewById(R.id.progressBarGPS);
        tvStatusGPSProgressBar = findViewById(R.id.tvStatusGPSProgressBar);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Allow images displayed on the grid to be clickable for users to select them
        ivCache.setOnClickListener(view -> displayImageGrid());

        if (!gpsEnabled){
            // Only allow the GPS button to be clickable when location services are enabled
            gpsButton.setEnabled(false);
        }

        // Any changes to the name input field are caught here
        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                // Only allow the create button to be clickable when a name is entered
                createButton.setEnabled(!charSequence.toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        backButton.setOnClickListener(view -> {
            CacheListActivity();
            finish();
        });

        createButton.setOnClickListener(view -> {
            int id = 0;
            int userId = sessionManager.getUserId();
            String name = etName.getText().toString();
            String hint = etHint.getText().toString();
            String latitudeString = etLatitude.getText().toString();
            String longitudeString = etLongitude.getText().toString();
            double latitude = 0.0;
            double longitude = 0.0;

            try {
                latitude = Double.parseDouble(latitudeString);
                latitude = Double.parseDouble(String.format("%.6f", latitude));
            } catch (NumberFormatException ignored) {
            }

            try {
                longitude = Double.parseDouble(longitudeString);
                longitude = Double.parseDouble(String.format("%.6f", longitude));
            } catch (NumberFormatException ignored) {
            }

            // If the image ID falls out of bounds, reset it to 0
            if (chosenImageIndex < 0 || chosenImageIndex >= drawableCacheIDs.length){
                chosenImageIndex = 0;
            }

            databaseManager.createNewCache(new CacheModel(id ,userId, name, hint, latitude, longitude, chosenImageIndex));

            CacheListActivity();
            finish();
        });

        // When connecting to the GPS sensor to obtain current coordinates, makes
        // a progress wheel and validating text temporarily appear and ensure the
        // GPS button is unable to be clicked until the process finishes
        gpsButton.setOnClickListener(view -> {
            Location lastKnownLocation = gpsManager.getLastKnownLocation();
            if (lastKnownLocation != null) {
                Double lastKnownLat = Double.valueOf(String.valueOf(lastKnownLocation.getLatitude()));
                Double lastKnownLong = Double.valueOf(String.valueOf(lastKnownLocation.getLongitude()));
                etLatitude.setText(String.format("%.6f", lastKnownLat));
                etLongitude.setText(String.format("%.6f", lastKnownLong));
            }
            fetchingGPS = true;
            progressBarGPS.setVisibility(View.VISIBLE);
            tvStatusGPSProgressBar.setVisibility(View.VISIBLE);
            gpsButton.setEnabled(false);
            gpsManager.getCurrentLocation();
        });

        // Managing the back stack and keeping the database updated by manually handling the back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            public void handleOnBackPressed() {
                try {
                    CacheListActivity();
                    finish();
                } catch (Exception ignored) {
                }
            }
        });
    }

    // Turns off the visibility of the progress bar and validating text,
    // and allows the GPS button to be clicked again
    public void toggleGPSFetch(){
        fetchingGPS = false;
        progressBarGPS.setVisibility(View.GONE);
        tvStatusGPSProgressBar.setVisibility(View.GONE);
        gpsButton.setEnabled(true);
    }

    public void CacheListActivity(){
        Intent intent = new Intent (this, CacheListActivity.class);
        startActivity(intent);
    }

    // For displaying a grid of images to select for the created Cache's associated image
    private void displayImageGrid(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Choose");

        View image_select_grid = getLayoutInflater().inflate(R.layout.image_select_grid, null);
        GridView gridView = image_select_grid.findViewById(R.id.gridView);

        SelectImageGridAdapter adapter = new SelectImageGridAdapter(this, drawableCacheIDs);
        gridView.setAdapter(adapter);

        builder.setView(image_select_grid);

        AlertDialog dialog = builder.create();
        dialog.show();

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            chosenImageIndex = position;
            ivCache.setImageResource(drawableCacheIDs[chosenImageIndex]);
            dialog.dismiss();
        });
    }

    // Ensures the GPS sensor is shut off, conserving battery life, when
    // this activity is closed for any reason before the location fetching completes
    @Override
    protected void onDestroy(){
        super.onDestroy();
        gpsManager.cancelLocationUpdates();
    }

    // Updates the UI display for the latitude and longitude after a
    // user updates the GPS coordinates by clicking the GPS button
    @SuppressLint("DefaultLocale")
    @Override
    public void onLocationUpdated(double latitude, double longitude, float accuracy){
        runOnUiThread(()-> {
            etLatitude.setText(String.format("%.6f", latitude));
            etLongitude.setText(String.format("%.6f", longitude));
        });
    }
}