package com.wildnotion.snhu_cs499_clark_stashcache;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

// For managing all interaction between all class methods and the SQLite database
public class DatabaseManager extends SQLiteOpenHelper {
    // For keeping track of the logged in User
    private final SessionManager sessionManager = SessionManager.getSession();

    // Singleton pattern here (private static instance, private constructor, method to get/create)
    // to ensure only one DatabaseManager exists in memory
    private static DatabaseManager database;


    private DatabaseManager(Context context){
        super(context.getApplicationContext(), DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized DatabaseManager getDatabase(Context context){
        if (database == null) {
            database = new DatabaseManager(context.getApplicationContext());
        }
        return  database;
    }

    // Database name, version, and instance declarations
    private static final String DATABASE_NAME = "StashCache.db";
    private static final int DATABASE_VERSION = 1;

    // Username & Password table
    private static final String USER_TABLE = "USER_TABLE";
    private static final String COLUMN_USER_ID = "ID";
    private static final String COLUMN_USER_NAME = "USERNAME";
    private static final String COLUMN_USER_PASS = "PASSWORD";

    // Individual Cache table
    private static final String CACHE_TABLE = "CACHE_TABLE";
    private static final String COLUMN_CACHE_ID = "ID";
    private static final String COLUMN_CACHE_USER_ID = "USER_ID";
    private static final String COLUMN_CACHE_NAME = "NAME";
    private static final String COLUMN_CACHE_HINT = "HINT";
    private static final String COLUMN_CACHE_LATITUDE = "LATITUDE";
    private static final String COLUMN_CACHE_LONGITUDE = "LONGITUDE";
    private static final String COLUMN_CACHE_IMAGE = "IMAGE";

    // Individual Item table
    private static final String ITEM_TABLE = "ITEM_TABLE";
    private static final String COLUMN_ITEM_ID = "ID";
    private static final String COLUMN_ITEM_CACHE_ID = "CACHE_ID";
    private static final String COLUMN_ITEM_NAME = "NAME";
    private static final String COLUMN_ITEM_DESCRIPTION = "DESCRIPTION";
    private static final String COLUMN_ITEM_COUNT = "COUNT";
    private static final String COLUMN_ITEM_IMAGE = "IMAGE";

    // Necessary override of the extended SQLiteOpenHelper
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Create a master Username & Password table
        String createMasterUserPassTable = "CREATE TABLE " + USER_TABLE + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_NAME + " TEXT NOT NULL UNIQUE, "
                + COLUMN_USER_PASS + " TEXT NOT NULL);";
        sqLiteDatabase.execSQL(createMasterUserPassTable);

        // Create a master Cache table
        String createMasterCacheTable = "CREATE TABLE " + CACHE_TABLE + " (" +
                COLUMN_CACHE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_CACHE_USER_ID + " INTEGER NOT NULL, " +
                COLUMN_CACHE_NAME + " TEXT NOT NULL, " +
                COLUMN_CACHE_HINT + " TEXT, " +
                COLUMN_CACHE_LATITUDE + " REAL, " +
                COLUMN_CACHE_LONGITUDE + " REAL, " +
                COLUMN_CACHE_IMAGE + " INTEGER, " +
                "FOREIGN KEY(" + COLUMN_CACHE_USER_ID + ") REFERENCES " +
                USER_TABLE + "(" + COLUMN_USER_ID + ") ON DELETE CASCADE);";
        sqLiteDatabase.execSQL(createMasterCacheTable);

        // Create a master Item table
        String createMasterItemTable = "CREATE TABLE " + ITEM_TABLE + " (" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_CACHE_ID + " INTEGER NOT NULL, " +
                COLUMN_ITEM_NAME + " TEXT NOT NULL, " +
                COLUMN_ITEM_DESCRIPTION + " TEXT, " +
                COLUMN_ITEM_COUNT + " INTEGER, " +
                COLUMN_ITEM_IMAGE + " INTEGER, " +
                "FOREIGN KEY(" + COLUMN_ITEM_CACHE_ID + ") REFERENCES " +
                CACHE_TABLE + "(" + COLUMN_CACHE_ID + ") ON DELETE CASCADE);";
        sqLiteDatabase.execSQL(createMasterItemTable);
    }

    // Necessary override of the extended SQLiteOpenHelper to drop and update old databases
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + CACHE_TABLE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + ITEM_TABLE);
        this.onCreate(sqLiteDatabase);
    }

    // Creates a new User with the Username and Password input on the Login activity
    public UserPassModel createNewUser(UserPassModel userPassModel){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        try {
            sqLiteDatabase.beginTransaction();

            String encryptedUsername = userPassModel.getUsername();
            String encryptedPassword = userPassModel.getPassword();

            contentValues.put(COLUMN_USER_NAME, encryptedUsername);
            contentValues.put(COLUMN_USER_PASS, encryptedPassword);

            long result = sqLiteDatabase.insert(USER_TABLE, null, contentValues);

            if (result != -1) {
                userPassModel.setId((int) result);
                sqLiteDatabase.setTransactionSuccessful();
                return userPassModel;
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        } finally {
            sqLiteDatabase.endTransaction();
            sqLiteDatabase.close();
        }
    }


    // Creates a new Cache associated to the logged in User so they may store Items
    public boolean createNewCache(CacheModel cacheModel){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        try {
            String encryptedName = EncryptionManager.encryptData(cacheModel.getName());
            String encryptedHint = EncryptionManager.encryptData(cacheModel.getHint());
            String encryptedLatitude = EncryptionManager.encryptData(String.valueOf(cacheModel.getLatitude()));
            String encryptedLongitude = EncryptionManager.encryptData(String.valueOf(cacheModel.getLongitude()));
            String encryptedImage = EncryptionManager.encryptData(String.valueOf(cacheModel.getImage()));
            contentValues.put(COLUMN_CACHE_USER_ID, cacheModel.getUserId());
            contentValues.put(COLUMN_CACHE_NAME, encryptedName);
            contentValues.put(COLUMN_CACHE_HINT, encryptedHint);
            contentValues.put(COLUMN_CACHE_LATITUDE, encryptedLatitude);
            contentValues.put(COLUMN_CACHE_LONGITUDE, encryptedLongitude);
            contentValues.put(COLUMN_CACHE_IMAGE, encryptedImage);

            long result = sqLiteDatabase.insert(CACHE_TABLE, null, contentValues);
            sqLiteDatabase.close();

            if (result != -1){
                cacheModel.setId((int) result);
                sqLiteDatabase.close();
                return true;
            } else {
                sqLiteDatabase.close();
                return false;
            }
        } catch (Exception e) {
            sqLiteDatabase.close();
            return false;
        }
    }

    // Add an Item to an associated Cache
    public boolean addItemToCache(ItemModel itemModel){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        try {
            String encryptedName = EncryptionManager.encryptData(itemModel.getName());
            String encryptedDescription = EncryptionManager.encryptData(itemModel.getDescription());
            String encryptedCount = EncryptionManager.encryptData(String.valueOf(itemModel.getCount()));
            String encryptedImage = EncryptionManager.encryptData(String.valueOf(itemModel.getImage()));

            contentValues.put(COLUMN_ITEM_CACHE_ID, itemModel.getCacheId());
            contentValues.put(COLUMN_ITEM_NAME, encryptedName);
            contentValues.put(COLUMN_ITEM_DESCRIPTION, encryptedDescription);
            contentValues.put(COLUMN_ITEM_COUNT, encryptedCount);
            contentValues.put(COLUMN_ITEM_IMAGE, encryptedImage);

            long result = sqLiteDatabase.insert(ITEM_TABLE, null, contentValues);

            if (result != -1){
                itemModel.setId((int) result);
                sqLiteDatabase.close();
                return  true;
            } else {
                sqLiteDatabase.close();
                return false;
            }
        } catch (Exception e) {
            sqLiteDatabase.close();
            return false;
        }
    }

    // Returns a list of all Caches associated with a User
    public List<CacheModel> getUserCaches(){
        List<CacheModel> userCaches = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        int sessionID = sessionManager.getUserId();

        String sqlQuery = "SELECT * FROM " + CACHE_TABLE + " WHERE " + COLUMN_CACHE_USER_ID + " = ?";
        Cursor cursor = sqLiteDatabase.rawQuery(sqlQuery, new String[]{String.valueOf(sessionID)});

        try {
            if (cursor.moveToFirst()) {
                do {
                    int cacheID = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_ID));
                    int cacheUserID = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_USER_ID));

                    String encryptedName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_NAME));
                    String encryptedHint = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_HINT));
                    String encryptedLatitude = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_LATITUDE));
                    String encryptedLongitude = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_LONGITUDE));
                    String encryptedImage = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_IMAGE));

                    String cacheName = EncryptionManager.decryptData(encryptedName);
                    String cacheHint = EncryptionManager.decryptData(encryptedHint);
                    double cacheLatitude = Double.parseDouble(EncryptionManager.decryptData(encryptedLatitude));
                    double cacheLongitude =  Double.parseDouble(EncryptionManager.decryptData(encryptedLongitude));
                    int cacheImage = Integer.parseInt(EncryptionManager.decryptData(encryptedImage));
                    userCaches.add(new CacheModel(cacheID, cacheUserID, cacheName, cacheHint, cacheLatitude, cacheLongitude, cacheImage));
                } while (cursor.moveToNext());
            }
        } catch (Exception ignored){
        } finally {
            cursor.close();
            sqLiteDatabase.close();
        }

        return userCaches;
    }

    // Returns a list of all the Items associated with a Cache's inventory
    public List<ItemModel> getCurrentCacheItems(int cacheID){
        List<ItemModel> cacheItems = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();

        String sqlQuery = "SELECT * FROM " + ITEM_TABLE + " WHERE " + COLUMN_ITEM_CACHE_ID + " = ?";
        Cursor cursor = sqLiteDatabase.rawQuery(sqlQuery, new String[]{String.valueOf(cacheID)});

        try {
            if (cursor.moveToFirst()) {
                do {
                    int id = Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)));

                    String encryptedName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                    String encryptedDescription = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_DESCRIPTION));
                    String encryptedCount = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_COUNT));
                    String encryptedImage = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_IMAGE));

                    String itemName = EncryptionManager.decryptData(encryptedName);
                    String itemDescription = EncryptionManager.decryptData(encryptedDescription);
                    int itemCount = Integer.parseInt(EncryptionManager.decryptData(encryptedCount));
                    int itemImage = Integer.parseInt(EncryptionManager.decryptData(encryptedImage));
                    cacheItems.add(new ItemModel(id, cacheID, itemName, itemDescription, itemCount, itemImage));
                } while (cursor.moveToNext());
            }
        } catch (Exception ignored){
        }

        cursor.close();
        sqLiteDatabase.close();
        return cacheItems;
    }

    // Returns a specific User with verified Username & Password to access their created Caches
    public UserPassModel getUsernameID(String username){
        try (SQLiteDatabase sqLiteDatabase = this.getReadableDatabase(); Cursor cursor = sqLiteDatabase.query(USER_TABLE, new String[]{COLUMN_USER_ID,
                        COLUMN_USER_NAME, COLUMN_USER_PASS},
                null, null, null, null, null)) {

            if (cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
                    @SuppressLint("Range") String encryptedUsername = cursor.getString(cursor.getColumnIndex(COLUMN_USER_NAME));
                    @SuppressLint("Range") String encryptedPassword = cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASS));

                    String decryptedUsername = EncryptionManager.decryptData(encryptedUsername);

                    if (decryptedUsername.equals(username)) {
                        UserPassModel userPassModel = new UserPassModel(encryptedUsername, encryptedPassword);
                        userPassModel.setId(id);
                        return userPassModel;
                    }
                } while (cursor.moveToNext());
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    // Deletes a Cache from a User's Cache list when selecting the minus image next to the Cache's image
    public void deleteCacheById(int cacheID) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        int userID = sessionManager.getUserId();

        sqLiteDatabase.delete(CACHE_TABLE, COLUMN_CACHE_ID + " = ? AND " +
                COLUMN_CACHE_USER_ID + " = ?", new String[]{String.valueOf(cacheID), String.valueOf(userID)});

        sqLiteDatabase.close();
    }

    // Deletes an Item from a Cache's inventory when selecting the minus image next to the Item's image
    public boolean deleteItemByID(int itemID) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        int cacheID = sessionManager.getCacheID();

        boolean success = false;
        try {
            sqLiteDatabase.beginTransaction();

            int confirmDelete = sqLiteDatabase.delete(ITEM_TABLE,
                    COLUMN_ITEM_ID + " = ? AND " + COLUMN_ITEM_CACHE_ID + " = ?",
                                new String[]{String.valueOf(itemID), String.valueOf(cacheID)});

            if (confirmDelete > 0) {
                success = true;
            }
            sqLiteDatabase.setTransactionSuccessful();
        } catch (Exception ignored) {
        } finally {
            sqLiteDatabase.endTransaction();
            sqLiteDatabase.close();
        }

        return success;
    }

    // Deletes the active User after a confirmation pop-up is presented in the Options activity
    public void deleteActiveUser(){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        int userID = sessionManager.getUserId();
        sqLiteDatabase.delete(USER_TABLE, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(userID)});

        sqLiteDatabase.close();
    }

    // Returns a specific Cache to display the Items associated with it in the Inventory activity
    public CacheModel getCacheById(int cacheID) {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        CacheModel cacheModel = null;

        String sqlQuery = "SELECT * FROM " + CACHE_TABLE + " WHERE " + COLUMN_CACHE_ID + " = ?";
        Cursor cursor = sqLiteDatabase.rawQuery(sqlQuery, new String[]{String.valueOf(cacheID)});

        try{
            if (cursor.moveToFirst()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_ID));
                int userId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CACHE_USER_ID));

                String encryptedName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_NAME));
                String encryptedHint = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_HINT));
                String encryptedLatitude = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_LATITUDE));
                String encryptedLongitude = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_LONGITUDE));
                String encryptedImage = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CACHE_IMAGE));

                String name = EncryptionManager.decryptData(encryptedName);
                String hint = EncryptionManager.decryptData(encryptedHint);
                double latitude = Double.parseDouble(EncryptionManager.decryptData(encryptedLatitude));
                double longitude = Double.parseDouble(EncryptionManager.decryptData(encryptedLongitude));
                int image = Integer.parseInt(EncryptionManager.decryptData(encryptedImage));

                cacheModel = new CacheModel(id, userId, name, hint, latitude, longitude, image);
            }
        } catch (Exception ignored) {
        } finally {
            cursor.close();
            sqLiteDatabase.close();
        }

        return cacheModel;
    }
}
