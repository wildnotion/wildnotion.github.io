package com.wildnotion.snhu_cs499_clark_stashcache;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Looper;

import androidx.core.content.ContextCompat;

// For temporarily accessing the GPS sensor to acquire current coordinates, as well as a quick
// string from the GPS sensor's last known location in case of weak satellite connectivity
public class GPSManager {
    public double latitude;
    public double longitude;
    public float accuracy;

    private final LocationManager locationManager;
    private LocationListener locationListener;
    private final Context context;
    private final GPSListener gpsListener;
    private final GPSFetchCallback gpsFetchCallback;

    public interface GPSListener {
        void onLocationUpdated(double latitude, double longitude, float accuracy);
    }

    public GPSManager(Context context, GPSListener listener, GPSFetchCallback gpsFetchCallback){
        this.context = context;
        this.locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        this.gpsListener = listener;
        this.gpsFetchCallback = gpsFetchCallback;
    }

    // Returns the last known location for populating a quick string on the layout,
    // with a more accurate reading to follow from getCurrentLocation
    public Location getLastKnownLocation(){
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){
            return locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        }
        return null;
    }

    // Returns the current location, and stops requesting updates after
    // an acceptable accuracy is reached to conserve battery life
    public void getCurrentLocation(){
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){
            locationListener = location -> {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                accuracy = location.getAccuracy();

                if(gpsListener != null){
                    gpsListener.onLocationUpdated(latitude, longitude, accuracy);
                }

                if (accuracy < 20) {
                    cancelLocationUpdates();

                    if (gpsFetchCallback != null) {
                        gpsFetchCallback.toggleGPSFetch();
                    }
                }
            };
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,
                    locationListener, Looper.getMainLooper());
        }
    }

    // Stops using the GPS sensor to find the current location
    public void cancelLocationUpdates() {
        if(locationListener != null){
            locationManager.removeUpdates(locationListener);
        }
    }

    // Updates the display on the create cache activity's layout after obtaining the GPS coordinates
    public interface GPSFetchCallback {
        void toggleGPSFetch();
    }

    public boolean gpsEnabled(){
        return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }
}
