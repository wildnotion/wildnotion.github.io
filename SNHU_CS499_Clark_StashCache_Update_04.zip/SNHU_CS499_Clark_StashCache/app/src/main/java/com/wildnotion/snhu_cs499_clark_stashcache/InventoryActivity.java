package com.wildnotion.snhu_cs499_clark_stashcache;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// For displaying a cache's information including the list of items it contains,
// as well as a button to copy the GPS coordinate for pasting in a map app
public class InventoryActivity extends AppCompatActivity {

    TextView tvCacheName;
    TextView tvCacheHint;
    TextView tvLatitude;
    TextView tvLongitude;
    ImageView ivCacheImage;
    RecyclerView recyclerView;

    private final int[] drawableCacheIDs = {
            R.drawable.location_snowy, R.drawable.location_overlook, R.drawable.location_desert,
            R.drawable.location_tavern, R.drawable.location_glade, R.drawable.location_crystal,
            R.drawable.location_basement, R.drawable.location_mushrooms, R.drawable.location_shipwreck
    };

    // Singleton classes to manage database interaction with an authorized user
    SessionManager sessionManager;
    DatabaseManager databaseManager;

    // References for the buttons on the user interface
    Button cacheListButton;
    Button addItemButton;
    Button gpsCopyButton;

    int cacheID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        tvCacheName = findViewById(R.id.tvCacheName);
        tvCacheHint = findViewById(R.id.tvCacheHint);
        tvLatitude = findViewById(R.id.tvLatitude);
        tvLongitude = findViewById(R.id.tvLongitude);
        ivCacheImage = findViewById(R.id.ivCacheImage);
        recyclerView = findViewById(R.id.recyclerView);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        cacheID = sessionManager.getCacheID();
        CacheModel cacheModel = databaseManager.getCacheById(cacheID);

        if(cacheModel != null) {
            String cacheName = cacheModel.getName();
            String cacheHint = cacheModel.getHint();
            double latitude = cacheModel.getLatitude();
            double longitude = cacheModel.getLongitude();
            int cacheImage = cacheModel.getImage();

            tvCacheName.setText(cacheName);
            tvCacheHint.setText(cacheHint);
            tvLatitude.setText(String.valueOf(latitude));
            tvLongitude.setText(String.valueOf(longitude));
            ivCacheImage.setImageResource(drawableCacheIDs[cacheImage]);

            gpsCopyButton = findViewById(R.id.gpsCopyButton);
            cacheListButton = findViewById(R.id.cacheListButton);
            addItemButton = findViewById(R.id.addItemButton);

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });

            // For setting up the area where the items will be displayed
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            // For adding lines to the recycler view
            recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

            // For displaying a list of items per cache stored in the SQLite Database
            List<ItemModel> itemModelList = databaseManager.getCurrentCacheItems(cacheID);

            // For future item updates, similar to clicking on a cache to open its inventory
            // this adds a button click capability to the items displayed by the adapter
            SQLItemViewAdapter sqlItemViewAdapter = new SQLItemViewAdapter(itemModelList,
                    position -> {}, databaseManager
            );
            recyclerView.setAdapter(sqlItemViewAdapter);
        }

        // Copy the location data to the device's clipboard for pasting in a map app
        gpsCopyButton.setOnClickListener(view -> {
            assert cacheModel != null;
            double latitude = cacheModel.getLatitude();
            double longitude = cacheModel.getLongitude();
            String copiedCoordinates = latitude + ", " + longitude;

            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clipData = ClipData.newPlainText("Copied Coordinates", copiedCoordinates);
            clipboardManager.setPrimaryClip(clipData);

            Toast.makeText(this, "Coordinates copied to clipboard.", Toast.LENGTH_SHORT).show();
        });

        cacheListButton.setOnClickListener(view -> {
            CacheListActivity();
            finish();
        });

        addItemButton.setOnClickListener(view -> {
            AddItemActivity();
            finish();
        });

        // Managing the back stack and keeping the database updated by manually handling the back button
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    CacheListActivity();
                    finish();
                } catch (Exception ignored) {
                }
            }
        });
    }

    public void CacheListActivity(){
        Intent intent = new Intent (this, CacheListActivity.class);
        startActivity(intent);
    }

    public void AddItemActivity(){
        Intent intent = new Intent (this, AddItemActivity.class);
        startActivity(intent);
    }
}