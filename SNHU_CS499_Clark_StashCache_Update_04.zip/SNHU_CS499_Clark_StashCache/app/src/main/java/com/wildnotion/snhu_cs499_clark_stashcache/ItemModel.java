package com.wildnotion.snhu_cs499_clark_stashcache;

// For storing Items associated with Caches in the SQLite database
public class ItemModel {
    private int id;
    private final int cacheId;
    private String name;
    private String description;
    private int count;
    private int image;

    public ItemModel(int id, int cacheId, String name, String description, int count, int image){
        this.id = id;
        this.cacheId = cacheId;
        this.name = name;
        this.description = description;
        this.count = count;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getCacheId() {
        return cacheId;
    }
}
