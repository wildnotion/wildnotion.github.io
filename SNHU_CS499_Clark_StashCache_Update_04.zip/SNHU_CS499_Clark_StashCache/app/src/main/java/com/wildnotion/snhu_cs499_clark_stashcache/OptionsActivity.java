package com.wildnotion.snhu_cs499_clark_stashcache;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// For choosing to toggle location services or delete an active user
public class OptionsActivity extends AppCompatActivity {
    // Singleton classes to manage database interaction with an authorized user
    SessionManager sessionManager;
    DatabaseManager databaseManager;

    // UI button declaration
    Button locationButton;
    TextView tvStatus;
    Button backButton;
    Button deleteActiveUserButton;

    // Code for GPS location services, unfortunately hardcoded
    private static final int LOCATION_PERMISSION_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_options);

        sessionManager = SessionManager.getSession();
        databaseManager = DatabaseManager.getDatabase(getApplicationContext());

        // When a user denies location services from the app settings
        // they will affect the session ID, which requires a full restart
        int sessionID = sessionManager.getUserId();
        if (sessionID <= 0){
            onSettingsUpdate();
        }

        // UI button setup
        locationButton = findViewById(R.id.locationButton);
        tvStatus = findViewById(R.id.tvStatus);
        backButton = findViewById(R.id.backButton);
        deleteActiveUserButton = findViewById(R.id.deleteActiveUserButton);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set layout status text to current location permission status
        updateLocationStatus();

        // Call the method below that toggles permissions for location services
        locationButton.setOnClickListener(view -> ToggleLocationPermissions());

        // Return to previous activity
        backButton.setOnClickListener(view -> finish());

        // Pop-up to confirm the request of deleting the active user
        deleteActiveUserButton.setOnClickListener(view -> new AlertDialog.Builder(this)
                .setTitle("Delete active user account?")
                .setMessage("Are you sure you want to delete this active user account?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    databaseManager.deleteActiveUser();
                    onSettingsUpdate();
                })
                .setNegativeButton("No", null)
                .show());
    }

    // Upon clicking the locations button on the layout when the current status is denied, the Android
    // location permissions pop-up appears for a user to select from, however when the current status is
    // granted, an alert message appears with a redirect to the application's settings to revoke permissions
    public void ToggleLocationPermissions(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {

            new AlertDialog.Builder(this)
                            .setTitle("Deny location permissions?")
                            .setMessage("Location permissions are currently granted. Would you like to deny location permissions?" +
                                    "\n(Requires manually updating the 'Permissions' in 'App info'.)" +
                                    "\n(Adjusting the permission will restart the application.)")
                                    .setPositiveButton("Yes", (dialog, which) -> {
                                        // Open app settings
                                        Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                                        intent.setData(Uri.parse("package:" + getPackageName()));
                                        startActivity(intent);
                                    })
                                    .setNegativeButton("No", null)
                                    .show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_CODE);
        }
    }

    // Update the display of the permission status for the location services
    private void updateLocationStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            tvStatus.setText(R.string.granted);
        } else {
            tvStatus.setText(R.string.denied);
        }
    }

    // After deleting an active user account or denying the GPS app setting,
    // the app is restart to ensure updated data and proper session management
    public void onSettingsUpdate(){
        Intent intent = new Intent (this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        finishAffinity();
        startActivity(intent);
    }

    @Override
    public void onResume(){
        super.onResume();
        // Updates the status when turning on GPS location services
        updateLocationStatus();
    }
}