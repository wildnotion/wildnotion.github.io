package com.wildnotion.snhu_cs499_clark_stashcache;
/*
A reference for the SQLite database tables to keep track of active user and active cache.
Used for logging in, and the CRUD (create, read, update, and delete) functionality of the database.
*/
public class SessionManager {
    // For the singleton pattern, : a private static final variable is created at the application's start, and may be referenced throughout
    private static final SessionManager session = new SessionManager();
    private int userId;
    private int cacheID;

    // Constructor
    private SessionManager(){
    }

    // Singleton pattern in getter, no need for setter
    public static SessionManager getSession() {
        return session;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void logoutSession(){
        this.userId = -1;
    }

    public int getCacheID() {
        return cacheID;
    }

    public void setCacheID(int cacheID) {
        this.cacheID = cacheID;
    }
}
